// Telegram: one bot for the whole platform.
//  - Each user links their Telegram by tapping a one-time link (t.me/<bot>?start=<code>).
//  - With Telegram Business (Premium), the user adds the bot under Settings > Telegram Business > Chatbots:
//    every private chat then arrives live and replies are sent as the user.
//  - Without Premium, the user can forward any message to the bot to add it.
const { config } = require('../config');
const { request } = require('../http');
const db = require('../db');
const { encrypt, randomToken, safeEqual } = require('../crypto');
const ingest = require('../ingest');
const { clip, iso } = require('./util');

const P = 'Telegram';
const tg = (method) => `${config.hosts.telegram}/bot${config.telegram.botToken}/${method}`;
const call = (method, body) => request(tg(method), { method: 'POST', platform: P, body }).then((r) => r.result);
const nameOf = (u) => (u ? [u.first_name, u.last_name].filter(Boolean).join(' ') || (u.username ? '@' + u.username : 'Telegram user') : 'Telegram user');

let onNewMessages = async () => {}; // set by sync.js so new messages get AI triage

function textOf(m) {
  if (m.text) return m.text;
  if (m.caption) return m.caption;
  if (m.photo) return '[Photo]';
  if (m.voice) return '[Voice message]';
  if (m.video) return '[Video]';
  if (m.video_note) return '[Video message]';
  if (m.sticker) return `[Sticker ${m.sticker.emoji || ''}]`.trim();
  if (m.document) return `[File: ${m.document.file_name || 'document'}]`;
  if (m.location) return '[Location]';
  return '[Message]';
}

async function connectionByTelegramUser(tgUserId) {
  return db.one(`select * from connections where platform = 'telegram' and account_id = $1`, [String(tgUserId)]);
}

async function handleUpdate(update) {
  // The user added (or removed) the bot under Telegram Business > Chatbots
  if (update.business_connection) {
    const bc = update.business_connection;
    const conn = await connectionByTelegramUser(bc.user.id);
    if (conn) {
      await db.q(`update connections set meta = meta || $2 where id = $1`, [conn.id, JSON.stringify({ business_connection_id: bc.is_enabled ? bc.id : null, can_reply: !!(bc.rights ? bc.rights.can_reply : bc.can_reply) })]);
    }
    return;
  }

  // Someone messaged the user in a private chat (Telegram Business)
  const bm = update.business_message;
  if (bm) {
    const conn = await db.one(`select * from connections where platform = 'telegram' and meta->>'business_connection_id' = $1`, [bm.business_connection_id]);
    if (!conn) return;
    const fromMe = bm.from && String(bm.from.id) === conn.account_id;
    const chatName = bm.chat.title || nameOf(bm.chat);
    const { newInbound } = await ingest.saveConversations(conn, [{
      external_id: String(bm.chat.id),
      kind: 'dm',
      title: chatName,
      participant_name: chatName,
      participant_id: String(bm.chat.id),
      meta: { business_connection_id: bm.business_connection_id },
      messages: [{
        external_id: String(bm.message_id),
        direction: fromMe ? 'out' : 'in',
        sender_name: fromMe ? 'You' : nameOf(bm.from),
        text: clip(textOf(bm)),
        attachments: [],
        sent_at: iso(bm.date),
      }],
    }]);
    if (newInbound) await onNewMessages(conn.user_id);
    return;
  }

  const msg = update.message;
  if (!msg || !msg.from || msg.chat.type !== 'private') return;
  const text = (msg.text || '').trim();

  // Linking: /start <code>
  const start = /^\/start(?:\s+(\S+))?$/.exec(text);
  if (start) {
    const code = start[1];
    if (!code) {
      await call('sendMessage', { chat_id: msg.chat.id, text: `Hi! Open ${config.appName}, go to Connections and tap "Connect Telegram" to link this account.` });
      return;
    }
    const link = await db.one(`delete from pending_links where code = $1 and platform = 'telegram' and created_at > now() - interval '30 minutes' returning user_id`, [code]);
    if (!link) {
      await call('sendMessage', { chat_id: msg.chat.id, text: 'This link has expired. Tap "Connect Telegram" again in the app.' });
      return;
    }
    await db.q(
      `insert into connections (user_id, platform, account_id, account_name, token_enc, meta)
       values ($1, 'telegram', $2, $3, $4, $5)
       on conflict (user_id, platform, account_id) do update set account_name = excluded.account_name, status = 'ok', last_error = ''`,
      [link.user_id, String(msg.from.id), msg.from.username ? '@' + msg.from.username : nameOf(msg.from), encrypt('bot'), JSON.stringify({ chat_id: msg.chat.id })]
    );
    await call('sendMessage', {
      chat_id: msg.chat.id,
      text: `Connected to ${config.appName} ✅\n\nTo see ALL your Telegram chats there and reply to them:\nSettings → Telegram Business → Chatbots → add @${config.telegram.botUsername} (needs Telegram Premium).\n\nNo Premium? Forward any message here and it will appear in your inbox.`,
    });
    return;
  }

  // A forwarded message from a linked user
  const conn = await connectionByTelegramUser(msg.from.id);
  if (!conn) {
    await call('sendMessage', { chat_id: msg.chat.id, text: `This Telegram isn't linked yet. Open ${config.appName} → Connections → Connect Telegram.` });
    return;
  }
  const o = msg.forward_origin;
  const sender = o ? (o.sender_user ? nameOf(o.sender_user) : o.sender_user_name || (o.chat && (o.chat.title || nameOf(o.chat))) || 'Forwarded') : 'Note to self';
  const senderKey = o ? (o.sender_user ? String(o.sender_user.id) : o.chat ? String(o.chat.id) : 'name:' + sender) : 'self';
  const { newInbound } = await ingest.saveConversations(conn, [{
    external_id: 'fwd:' + senderKey,
    kind: 'dm',
    title: sender,
    participant_name: sender,
    participant_id: '',
    meta: { forwarded: true },
    messages: [{
      external_id: String(msg.message_id),
      direction: 'in',
      sender_name: sender,
      text: clip(textOf(msg)),
      attachments: [],
      sent_at: iso((o && o.date) || msg.date),
    }],
  }]);
  if (newInbound) await onNewMessages(conn.user_id);
  await call('sendMessage', { chat_id: msg.chat.id, text: 'Added to your inbox ✅', reply_to_message_id: msg.message_id }).catch(() => {});
}

async function setupWebhook() {
  if (!config.enabled.telegram) return 'off';
  if (config.publicUrl.startsWith('https://')) {
    await call('setWebhook', {
      url: `${config.publicUrl}/api/webhooks/telegram`,
      secret_token: config.telegram.webhookSecret || undefined,
      allowed_updates: ['message', 'business_connection', 'business_message'],
      drop_pending_updates: false,
    });
    return 'webhook';
  }
  startPolling();
  return 'polling';
}

// For running on your own computer (no public https address): ask Telegram for updates.
let polling = false;
function startPolling() {
  if (polling) return;
  polling = true;
  let offset = 0;
  (async () => {
    await call('deleteWebhook', {}).catch(() => {});
    while (polling) {
      try {
        const updates = await request(tg('getUpdates'), {
          method: 'POST', platform: P, timeoutMs: 40000,
          body: { offset, timeout: 30, allowed_updates: ['message', 'business_connection', 'business_message'] },
        });
        for (const u of updates.result || []) {
          offset = u.update_id + 1;
          await handleUpdate(u).catch((e) => console.error('Telegram update failed:', e.message));
        }
      } catch (e) {
        console.warn('Telegram polling:', e.message);
        await new Promise((r) => setTimeout(r, 5000));
      }
    }
  })();
}

module.exports = {
  id: 'telegram',
  name: 'Telegram',
  needs: 'Any Telegram account (all chats need Telegram Premium)',
  capabilities: { dm: true, comments: false, image: true, react: false, privateReply: false, linkFlow: true },
  enabled: () => config.enabled.telegram,

  async startLink(userId) {
    const code = randomToken(12);
    await db.q(`insert into pending_links (code, user_id, platform) values ($1, $2, 'telegram')`, [code, userId]);
    return `https://t.me/${config.telegram.botUsername}?start=${code}`;
  },

  checkSecret: (header) => !config.telegram.webhookSecret || safeEqual(header || '', config.telegram.webhookSecret),
  handleUpdate,
  setupWebhook,
  setOnNewMessages: (fn) => { onNewMessages = fn; },

  // Telegram pushes messages to us; nothing to pull.
  async sync() {
    return { conversations: [], stats: null };
  },

  async reply(conn, conv, { text, imageUrl }) {
    const bcid = conv.meta.business_connection_id;
    if (!bcid || conv.meta.forwarded) {
      throw Object.assign(new Error('Replies need Telegram Business: add the bot under Settings → Telegram Business → Chatbots. Forwarded messages can only be answered in Telegram.'), { status: 400 });
    }
    const r = imageUrl
      ? await call('sendPhoto', { business_connection_id: bcid, chat_id: conv.external_id, photo: imageUrl, caption: text || undefined })
      : await call('sendMessage', { business_connection_id: bcid, chat_id: conv.external_id, text });
    return { external_id: String(r.message_id), text: text || '', attachments: imageUrl ? [{ type: 'image', url: imageUrl }] : [] };
  },

  link() {
    return 'https://web.telegram.org/';
  },
};
