// Shared Google sign-in (used by YouTube and Gmail).
const { config } = require('../config');
const { request } = require('../http');
const { redirectUri, expiresAt } = require('./util');

function authUrl(platform, scopes, state) {
  const u = new URL(`${config.hosts.googleAccounts}/o/oauth2/v2/auth`);
  u.search = new URLSearchParams({
    client_id: config.google.clientId,
    redirect_uri: redirectUri(platform),
    response_type: 'code',
    scope: scopes.join(' '),
    access_type: 'offline',  // gives a refresh token so syncing keeps working
    prompt: 'consent',
    include_granted_scopes: 'true',
    state,
  });
  return u.toString();
}

async function exchangeCode(platform, code, label) {
  const t = await request(`${config.hosts.googleOauth}/token`, {
    method: 'POST', platform: label,
    form: {
      code,
      client_id: config.google.clientId,
      client_secret: config.google.clientSecret,
      redirect_uri: redirectUri(platform),
      grant_type: 'authorization_code',
    },
  });
  return { token: t.access_token, refresh: t.refresh_token, expires_at: expiresAt(t.expires_in) };
}

// Google access tokens last 1 hour; refresh a few minutes early.
async function refresh(conn, label) {
  if (conn.token_expires_at && new Date(conn.token_expires_at) - Date.now() > 5 * 60e3) return null;
  if (!conn.refresh) {
    const e = new Error(`${label}: please reconnect`);
    e.needsReconnect = true;
    throw e;
  }
  const t = await request(`${config.hosts.googleOauth}/token`, {
    method: 'POST', platform: label,
    form: { grant_type: 'refresh_token', refresh_token: conn.refresh, client_id: config.google.clientId, client_secret: config.google.clientSecret },
  });
  return { token: t.access_token, expires_at: expiresAt(t.expires_in), refresh: t.refresh_token || undefined };
}

module.exports = { authUrl, exchangeCode, refresh };
