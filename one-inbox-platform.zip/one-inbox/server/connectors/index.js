const list = [
  require('./instagram'),
  require('./facebook'),
  require('./youtube'),
  require('./gmail'),
  require('./telegram'),
];
const byId = Object.fromEntries(list.map((c) => [c.id, c]));

// Shown in the app as "coming next", with the honest reason.
const comingSoon = [
  { id: 'tiktok', name: 'TikTok', reason: "TikTok's API doesn't give apps access to DMs or comment replies yet." },
  { id: 'x', name: 'X (Twitter)', reason: 'Reading DMs and mentions needs a paid X API plan.' },
  { id: 'whatsapp', name: 'WhatsApp Business', reason: 'Needs a WhatsApp Business number on the Cloud API (personal WhatsApp has no API).' },
];

module.exports = { list, byId, comingSoon };
