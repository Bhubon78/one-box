const { config } = require('../config');

const redirectUri = (platform) => `${config.publicUrl}/api/connect/${platform}/callback`;
const clip = (s, n = 4000) => String(s ?? '').slice(0, n);
const iso = (t) => {
  if (t == null || t === '') return new Date().toISOString();
  const d = typeof t === 'number' ? new Date(t < 1e12 ? t * 1000 : t) : new Date(t);
  return isNaN(d) ? new Date().toISOString() : d.toISOString();
};
const expiresAt = (seconds) => (seconds ? new Date(Date.now() + Number(seconds) * 1000).toISOString() : null);

module.exports = { redirectUri, clip, iso, expiresAt };
