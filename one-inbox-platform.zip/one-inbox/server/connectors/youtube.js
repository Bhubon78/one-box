// YouTube: comments on your channel's videos, replies, and channel stats (YouTube Data API v3).
const { config } = require('../config');
const { request } = require('../http');
const google = require('./google');
const { clip, iso } = require('./util');

const P = 'YouTube';
const SCOPES = ['openid', 'email', 'https://www.googleapis.com/auth/youtube.force-ssl'];
const yt = (path) => `${config.hosts.googleApis}/youtube/v3/${path}`;
const auth = (conn) => ({ Authorization: `Bearer ${conn.token}` });

module.exports = {
  id: 'youtube',
  name: 'YouTube',
  needs: 'A YouTube channel',
  capabilities: { dm: false, comments: true, image: false, react: false, privateReply: false },
  enabled: () => config.enabled.youtube,

  authUrl: (state) => google.authUrl('youtube', SCOPES, state),

  async handleCallback(query) {
    const t = await google.exchangeCode('youtube', query.code, P);
    const ch = await request(yt('channels'), { platform: P, headers: { Authorization: `Bearer ${t.token}` }, query: { part: 'snippet,statistics', mine: 'true' } });
    const c = (ch.items || [])[0];
    if (!c) throw new Error('This Google account has no YouTube channel.');
    return [{
      account_id: c.id,
      account_name: c.snippet.title,
      avatar_url: (c.snippet.thumbnails && c.snippet.thumbnails.default && c.snippet.thumbnails.default.url) || '',
      token: t.token, refresh: t.refresh, expires_at: t.expires_at,
      meta: {},
    }];
  },

  refresh: (conn) => google.refresh(conn, P),

  async sync(conn) {
    const out = { conversations: [], stats: null };
    const ch = await request(yt('channels'), { platform: P, headers: auth(conn), query: { part: 'statistics', id: conn.account_id } });
    const s = ((ch.items || [])[0] || {}).statistics || {};
    out.stats = {
      followers: s.hiddenSubscriberCount ? null : Number(s.subscriberCount || 0),
      metrics: { views: Number(s.viewCount || 0), videos: Number(s.videoCount || 0) },
    };

    const threads = await request(yt('commentThreads'), {
      platform: P, headers: auth(conn),
      query: { part: 'snippet,replies', allThreadsRelatedToChannelId: conn.account_id, maxResults: 50, order: 'time', textFormat: 'plainText' },
    });
    for (const th of threads.items || []) {
      const top = th.snippet.topLevelComment;
      const author = top.snippet.authorChannelId && top.snippet.authorChannelId.value;
      if (author === conn.account_id) continue; // your own comment
      const all = [top, ...((th.replies && th.replies.comments) || [])];
      out.conversations.push({
        external_id: th.id,
        kind: 'comment',
        title: 'Comment on your video',
        participant_name: top.snippet.authorDisplayName || 'YouTube viewer',
        participant_id: author || '',
        meta: { parent_id: top.id, video_id: th.snippet.videoId },
        messages: all.map((c) => {
          const fromMe = c.snippet.authorChannelId && c.snippet.authorChannelId.value === conn.account_id;
          return {
            external_id: c.id,
            direction: fromMe ? 'out' : 'in',
            sender_name: fromMe ? 'You' : c.snippet.authorDisplayName || 'YouTube viewer',
            text: clip(c.snippet.textOriginal || c.snippet.textDisplay),
            attachments: [],
            sent_at: iso(c.snippet.publishedAt),
          };
        }),
      });
    }
    return out;
  },

  async reply(conn, conv, { text }) {
    const r = await request(yt('comments'), {
      method: 'POST', platform: P, headers: auth(conn), query: { part: 'snippet' },
      body: { snippet: { parentId: conv.meta.parent_id, textOriginal: text } },
    });
    return { external_id: r.id, text };
  },

  link(conv) {
    return conv.meta.video_id ? `https://www.youtube.com/watch?v=${conv.meta.video_id}&lc=${conv.meta.parent_id}` : 'https://studio.youtube.com/';
  },
};
