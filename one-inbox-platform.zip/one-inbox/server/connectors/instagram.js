// Instagram (business or creator accounts) via the official "Instagram API with Instagram Login".
// Docs: developers.facebook.com/docs/instagram-platform/instagram-api-with-instagram-login
const { config } = require('../config');
const { request } = require('../http');
const { redirectUri, clip, iso, expiresAt } = require('./util');

const P = 'Instagram';
const SCOPES = ['instagram_business_basic', 'instagram_business_manage_messages', 'instagram_business_manage_comments'];
const graph = (path) => `${config.hosts.graphInstagram}/${config.meta.graphVersion}/${path}`;

module.exports = {
  id: 'instagram',
  name: 'Instagram',
  needs: 'An Instagram Creator or Business account',
  capabilities: { dm: true, comments: true, image: true, react: true, privateReply: true, replyWindowHours: 24 },
  enabled: () => config.enabled.instagram,

  authUrl(state) {
    const u = new URL(`${config.hosts.wwwInstagram}/oauth/authorize`);
    u.search = new URLSearchParams({
      client_id: config.meta.igAppId,
      redirect_uri: redirectUri('instagram'),
      response_type: 'code',
      scope: SCOPES.join(','),
      state,
    });
    return u.toString();
  },

  async handleCallback(query) {
    const short = await request(`${config.hosts.apiInstagram}/oauth/access_token`, {
      method: 'POST', platform: P,
      form: {
        client_id: config.meta.igAppId,
        client_secret: config.meta.igAppSecret,
        grant_type: 'authorization_code',
        redirect_uri: redirectUri('instagram'),
        code: String(query.code || '').replace(/#_$/, ''),
      },
    });
    const shortToken = short.access_token || (short.data && short.data[0] && short.data[0].access_token);
    const long = await request(`${config.hosts.graphInstagram}/access_token`, {
      platform: P, query: { grant_type: 'ig_exchange_token', client_secret: config.meta.igAppSecret, access_token: shortToken },
    });
    const me = await request(graph('me'), {
      platform: P,
      query: { fields: 'id,user_id,username,name,profile_picture_url,followers_count,media_count', access_token: long.access_token },
    });
    return [{
      account_id: String(me.user_id || me.id),
      account_name: '@' + me.username,
      avatar_url: me.profile_picture_url || '',
      token: long.access_token,
      expires_at: expiresAt(long.expires_in),
      meta: { username: me.username, app_scoped_id: String(me.id) },
    }];
  },

  // Long-lived tokens last 60 days; refresh when fewer than 10 days are left.
  async refresh(conn) {
    if (!conn.token_expires_at || new Date(conn.token_expires_at) - Date.now() > 10 * 864e5) return null;
    const r = await request(`${config.hosts.graphInstagram}/refresh_access_token`, {
      platform: P, query: { grant_type: 'ig_refresh_token', access_token: conn.token },
    });
    return { token: r.access_token, expires_at: expiresAt(r.expires_in) };
  },

  async sync(conn) {
    const token = conn.token;
    const mine = new Set([conn.account_id, conn.meta.app_scoped_id].filter(Boolean).map(String));
    const myUser = conn.meta.username;
    const out = { conversations: [], stats: null };

    const me = await request(graph('me'), { platform: P, query: { fields: 'followers_count,follows_count,media_count,profile_picture_url', access_token: token } });
    out.stats = { followers: me.followers_count ?? null, metrics: { following: me.follows_count, posts: me.media_count } };
    out.avatar_url = me.profile_picture_url;

    // ---- Direct messages ----
    const convs = await request(graph('me/conversations'), {
      platform: P, query: { platform: 'instagram', fields: 'id,updated_time,participants', limit: 25, access_token: token },
    });
    for (const c of convs.data || []) {
      if (conn.last_sync_at && c.updated_time && new Date(c.updated_time) < new Date(conn.last_sync_at) - 60e3) continue;
      const other = ((c.participants && c.participants.data) || []).find((p) => !mine.has(String(p.id)) && p.username !== myUser) || {};
      let msgs = [];
      const detail = await request(graph(c.id), {
        platform: P, query: { fields: 'messages.limit(10){id,created_time,from,to,message,attachments}', access_token: token },
      });
      msgs = (detail.messages && detail.messages.data) || [];
      // Some accounts only return message IDs: then fetch each message (API allows the latest 20).
      if (msgs.length && msgs[0].message === undefined && !msgs[0].from) {
        const full = [];
        for (const m of msgs.slice(0, 10)) {
          try {
            full.push(await request(graph(m.id), { platform: P, query: { fields: 'id,created_time,from,to,message,attachments', access_token: token } }));
          } catch { /* deleted or too old */ }
        }
        msgs = full;
      }
      out.conversations.push({
        external_id: c.id,
        kind: 'dm',
        title: other.username ? '@' + other.username : 'Instagram DM',
        participant_name: other.username ? '@' + other.username : 'Instagram user',
        participant_id: String(other.id || ''),
        meta: {},
        messages: msgs.map((m) => {
          const fromMe = m.from && (mine.has(String(m.from.id)) || m.from.username === myUser);
          return {
            external_id: m.id,
            direction: fromMe ? 'out' : 'in',
            sender_name: fromMe ? 'You' : (m.from && m.from.username ? '@' + m.from.username : 'Instagram user'),
            text: clip(m.message),
            attachments: attachmentsOf(m),
            sent_at: iso(m.created_time),
          };
        }),
      });
    }

    // ---- Comments on recent posts ----
    const media = await request(graph('me/media'), {
      platform: P, query: { fields: 'id,caption,timestamp,permalink,comments_count', limit: 10, access_token: token },
    });
    for (const post of media.data || []) {
      if (!post.comments_count) continue;
      const comments = await request(graph(`${post.id}/comments`), {
        platform: P,
        query: { fields: 'id,text,timestamp,username,from,replies{id,text,timestamp,username,from}', limit: 25, access_token: token },
      });
      for (const cm of comments.data || []) {
        if (cm.username === myUser) continue;
        const replies = (cm.replies && cm.replies.data) || [];
        out.conversations.push({
          external_id: 'comment:' + cm.id,
          kind: 'comment',
          title: 'Comment on: ' + clip(post.caption || 'your post', 60),
          participant_name: '@' + (cm.username || 'user'),
          participant_id: String((cm.from && cm.from.id) || ''),
          meta: { comment_id: cm.id, post_id: post.id, permalink: post.permalink },
          messages: [cm, ...replies].map((r) => {
            const fromMe = r.username === myUser;
            return {
              external_id: r.id,
              direction: fromMe ? 'out' : 'in',
              sender_name: fromMe ? 'You' : '@' + (r.username || 'user'),
              text: clip(r.text),
              attachments: [],
              sent_at: iso(r.timestamp),
            };
          }),
        });
      }
    }
    return out;
  },

  // mode: 'dm' (default), 'public' (reply under a comment), 'private' (DM the commenter)
  async reply(conn, conv, { text, imageUrl, mode }) {
    const token = conn.token;
    if (conv.kind === 'comment' && mode !== 'private') {
      const r = await request(graph(`${conv.meta.comment_id}/replies`), { method: 'POST', platform: P, form: { message: text, access_token: token } });
      return { external_id: r.id, text };
    }
    const recipient = conv.kind === 'comment' ? { comment_id: conv.meta.comment_id } : { id: conv.participant_id };
    // Instagram's documented format uses "attachments" (plural) for images.
    const message = imageUrl ? { attachments: { type: 'image', payload: { url: imageUrl } } } : { text };
    const r = await request(graph(`${conn.account_id}/messages`), {
      method: 'POST', platform: P, headers: { Authorization: `Bearer ${token}` }, body: { recipient, message },
    });
    return { external_id: r.message_id || `sent-${Date.now()}`, text: imageUrl ? '' : text, attachments: imageUrl ? [{ type: 'image', url: imageUrl }] : [] };
  },

  async react(conn, conv, messageExternalId, emoji) {
    await request(graph(`${conn.account_id}/messages`), {
      method: 'POST', platform: P, headers: { Authorization: `Bearer ${conn.token}` },
      body: { recipient: { id: conv.participant_id }, sender_action: 'react', payload: { message_id: messageExternalId, reaction: emoji } },
    });
  },

  link(conv) {
    if (conv.kind === 'comment') return conv.meta.permalink || 'https://www.instagram.com/';
    return 'https://www.instagram.com/direct/inbox/';
  },
};

function attachmentsOf(m) {
  const list = (m.attachments && m.attachments.data) || [];
  return list.map((a) => {
    const url = (a.image_data && a.image_data.url) || (a.video_data && a.video_data.url) || a.file_url || (a.payload && a.payload.url) || '';
    return { type: a.video_data ? 'video' : a.image_data ? 'image' : 'file', url };
  }).filter((a) => a.url);
}
