// Gmail: brand-deal and collaboration emails, read and reply (Gmail API).
const { config } = require('../config');
const { request } = require('../http');
const google = require('./google');
const { clip, iso } = require('./util');

const P = 'Gmail';
const SCOPES = ['openid', 'email', 'https://www.googleapis.com/auth/gmail.readonly', 'https://www.googleapis.com/auth/gmail.send'];
const DEFAULT_QUERY = 'in:inbox newer_than:7d -category:promotions -category:social';
const gm = (path) => `${config.hosts.gmail}/gmail/v1/users/me/${path}`;
const auth = (conn) => ({ Authorization: `Bearer ${conn.token}` });

const header = (msg, name) => {
  const h = ((msg.payload && msg.payload.headers) || []).find((x) => x.name.toLowerCase() === name.toLowerCase());
  return h ? h.value : '';
};
const parseFrom = (v) => {
  const m = /^\s*"?([^"<]*?)"?\s*<([^>]+)>\s*$/.exec(v || '');
  return m ? { name: m[1].trim() || m[2], email: m[2].trim() } : { name: (v || '').trim(), email: (v || '').trim() };
};
const b64url = (s) => Buffer.from(s || '', 'base64url').toString('utf8');

function bodyText(part) {
  if (!part) return '';
  if (part.mimeType === 'text/plain' && part.body && part.body.data) return b64url(part.body.data);
  for (const p of part.parts || []) {
    const t = bodyText(p);
    if (t) return t;
  }
  if (part.mimeType === 'text/html' && part.body && part.body.data) {
    return b64url(part.body.data).replace(/<style[\s\S]*?<\/style>|<script[\s\S]*?<\/script>/gi, '').replace(/<br\s*\/?>/gi, '\n').replace(/<[^>]+>/g, ' ').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/[ \t]+/g, ' ');
  }
  return '';
}
// Drop the quoted previous emails ("On Mon, X wrote:") so the thread stays readable.
const stripQuoted = (t) => t.split(/\r?\n(?:On .{5,200} wrote:|-{2,} ?Original Message ?-{2,}|From: .+\r?\nSent: )/)[0].trim();

// RFC 2047 encode a header value that has non-ASCII characters.
const encHeader = (s) => (/^[\x20-\x7e]*$/.test(s) ? s : `=?UTF-8?B?${Buffer.from(s, 'utf8').toString('base64')}?=`);
const safeHeader = (s) => String(s || '').replace(/[\r\n]+/g, ' ').trim();

module.exports = {
  id: 'gmail',
  name: 'Gmail',
  needs: 'A Gmail or Google Workspace account',
  capabilities: { dm: true, comments: false, image: false, react: false, privateReply: false },
  enabled: () => config.enabled.gmail,

  authUrl: (state) => google.authUrl('gmail', SCOPES, state),

  async handleCallback(query) {
    const t = await google.exchangeCode('gmail', query.code, P);
    const profile = await request(gm('profile'), { platform: P, headers: { Authorization: `Bearer ${t.token}` } });
    return [{
      account_id: profile.emailAddress,
      account_name: profile.emailAddress,
      avatar_url: '',
      token: t.token, refresh: t.refresh, expires_at: t.expires_at,
      meta: { query: DEFAULT_QUERY },
    }];
  },

  refresh: (conn) => google.refresh(conn, P),

  async sync(conn, ctx) {
    const out = { conversations: [], stats: null };
    const list = await request(gm('messages'), { platform: P, headers: auth(conn), query: { q: conn.meta.query || DEFAULT_QUERY, maxResults: 30 } });
    const known = await ctx.knownMessageIds(conn.id);
    const threads = new Map();
    for (const ref of list.messages || []) {
      if (known.has(ref.id)) continue;
      const msg = await request(gm(`messages/${ref.id}`), { platform: P, headers: auth(conn), query: { format: 'full' } });
      const from = parseFrom(header(msg, 'From'));
      const fromMe = from.email.toLowerCase() === conn.account_id.toLowerCase();
      const subject = header(msg, 'Subject') || '(no subject)';
      let th = threads.get(msg.threadId);
      if (!th) {
        th = {
          external_id: msg.threadId,
          kind: 'email',
          title: subject,
          participant_name: fromMe ? '' : from.name,
          participant_id: fromMe ? '' : from.email,
          meta: { subject },
          messages: [],
        };
        threads.set(msg.threadId, th);
      }
      if (!fromMe) {
        th.participant_name = th.participant_name || from.name;
        th.participant_id = th.participant_id || from.email;
        th.meta.reply_to = parseFrom(header(msg, 'Reply-To') || header(msg, 'From')).email;
        th.meta.last_message_id = header(msg, 'Message-ID');
      }
      const text = stripQuoted(bodyText(msg.payload)) || msg.snippet || '';
      th.messages.push({
        external_id: msg.id,
        direction: fromMe ? 'out' : 'in',
        sender_name: fromMe ? 'You' : from.name,
        text: clip(`${th.messages.length ? '' : subject + '\n\n'}${text}`, 6000),
        attachments: [],
        sent_at: iso(Number(msg.internalDate)),
      });
    }
    out.conversations = [...threads.values()];
    return out;
  },

  async reply(conn, conv, { text }) {
    const to = safeHeader(conv.meta.reply_to || conv.participant_id);
    if (!to) throw new Error('No address to reply to');
    const subject = safeHeader(conv.meta.subject || conv.title);
    const lines = [
      `To: ${to}`,
      `Subject: ${encHeader(/^re:/i.test(subject) ? subject : 'Re: ' + subject)}`,
      'MIME-Version: 1.0',
      'Content-Type: text/plain; charset="UTF-8"',
      'Content-Transfer-Encoding: base64',
    ];
    if (conv.meta.last_message_id) {
      lines.push(`In-Reply-To: ${safeHeader(conv.meta.last_message_id)}`, `References: ${safeHeader(conv.meta.last_message_id)}`);
    }
    const raw = lines.join('\r\n') + '\r\n\r\n' + Buffer.from(text, 'utf8').toString('base64').replace(/(.{76})/g, '$1\r\n');
    const r = await request(gm('messages/send'), {
      method: 'POST', platform: P, headers: auth(conn),
      body: { raw: Buffer.from(raw, 'utf8').toString('base64url'), threadId: conv.external_id },
    });
    return { external_id: r.id, text };
  },

  link(conv) {
    return `https://mail.google.com/mail/u/0/#inbox/${conv.external_id}`;
  },
};
