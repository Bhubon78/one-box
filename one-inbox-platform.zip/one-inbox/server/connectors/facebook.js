// Facebook Pages: Messenger conversations and comments on Page posts (Facebook Login + Graph API).
const { config } = require('../config');
const { request } = require('../http');
const { redirectUri, clip, iso } = require('./util');

const P = 'Facebook';
const SCOPES = ['pages_show_list', 'pages_messaging', 'pages_read_engagement', 'pages_read_user_content', 'pages_manage_engagement'];
const graph = (path) => `${config.hosts.graphFacebook}/${config.meta.graphVersion}/${path}`;

module.exports = {
  id: 'facebook',
  name: 'Facebook Page & Messenger',
  needs: 'A Facebook Page you manage',
  capabilities: { dm: true, comments: true, image: true, react: false, privateReply: true, replyWindowHours: 24 },
  enabled: () => config.enabled.facebook,

  authUrl(state) {
    const u = new URL(`${config.hosts.wwwFacebook}/${config.meta.graphVersion}/dialog/oauth`);
    u.search = new URLSearchParams({
      client_id: config.meta.appId,
      redirect_uri: redirectUri('facebook'),
      state,
      scope: SCOPES.join(','),
      response_type: 'code',
    });
    return u.toString();
  },

  async handleCallback(query) {
    const short = await request(graph('oauth/access_token'), {
      platform: P,
      query: { client_id: config.meta.appId, client_secret: config.meta.appSecret, redirect_uri: redirectUri('facebook'), code: query.code },
    });
    // A long-lived user token gives Page tokens that don't expire.
    const long = await request(graph('oauth/access_token'), {
      platform: P,
      query: { grant_type: 'fb_exchange_token', client_id: config.meta.appId, client_secret: config.meta.appSecret, fb_exchange_token: short.access_token },
    });
    const pages = await request(graph('me/accounts'), {
      platform: P, query: { fields: 'id,name,access_token,picture{url}', limit: 50, access_token: long.access_token },
    });
    if (!pages.data || !pages.data.length) throw new Error('No Facebook Pages found. Make sure you selected at least one Page when connecting.');
    return pages.data.map((pg) => ({
      account_id: String(pg.id),
      account_name: pg.name,
      avatar_url: (pg.picture && pg.picture.data && pg.picture.data.url) || '',
      token: pg.access_token,
      expires_at: null,
      meta: {},
    }));
  },

  async sync(conn) {
    const token = conn.token;
    const pageId = conn.account_id;
    const out = { conversations: [], stats: null };

    const page = await request(graph(pageId), { platform: P, query: { fields: 'followers_count,fan_count,picture{url}', access_token: token } });
    out.stats = { followers: page.followers_count ?? page.fan_count ?? null, metrics: { likes: page.fan_count } };
    out.avatar_url = page.picture && page.picture.data && page.picture.data.url;

    // ---- Messenger ----
    const convs = await request(graph(`${pageId}/conversations`), {
      platform: P,
      query: {
        platform: 'messenger',
        fields: 'id,updated_time,participants,messages.limit(10){id,created_time,from,to,message,attachments{image_data,video_data,file_url,mime_type,name}}',
        limit: 25,
        access_token: token,
      },
    });
    for (const c of convs.data || []) {
      if (conn.last_sync_at && c.updated_time && new Date(c.updated_time) < new Date(conn.last_sync_at) - 60e3) continue;
      const other = ((c.participants && c.participants.data) || []).find((p) => String(p.id) !== pageId) || {};
      out.conversations.push({
        external_id: c.id,
        kind: 'dm',
        title: other.name || 'Messenger',
        participant_name: other.name || 'Facebook user',
        participant_id: String(other.id || ''),
        meta: {},
        messages: ((c.messages && c.messages.data) || []).map((m) => {
          const fromMe = m.from && String(m.from.id) === pageId;
          return {
            external_id: m.id,
            direction: fromMe ? 'out' : 'in',
            sender_name: fromMe ? 'You' : (m.from && m.from.name) || 'Facebook user',
            text: clip(m.message),
            attachments: ((m.attachments && m.attachments.data) || []).map((a) => ({
              type: a.video_data ? 'video' : a.image_data ? 'image' : 'file',
              url: (a.image_data && a.image_data.url) || (a.video_data && a.video_data.url) || a.file_url || '',
            })).filter((a) => a.url),
            sent_at: iso(m.created_time),
          };
        }),
      });
    }

    // ---- Comments on recent Page posts ----
    const posts = await request(graph(`${pageId}/posts`), {
      platform: P,
      query: {
        fields: 'id,message,created_time,permalink_url,comments.limit(25).order(reverse_chronological){id,message,created_time,from,comments.limit(10){id,message,created_time,from}}',
        limit: 10,
        access_token: token,
      },
    });
    for (const post of posts.data || []) {
      for (const cm of (post.comments && post.comments.data) || []) {
        if (cm.from && String(cm.from.id) === pageId) continue;
        const replies = (cm.comments && cm.comments.data) || [];
        out.conversations.push({
          external_id: 'comment:' + cm.id,
          kind: 'comment',
          title: 'Comment on: ' + clip(post.message || 'your post', 60),
          participant_name: (cm.from && cm.from.name) || 'Facebook user',
          participant_id: String((cm.from && cm.from.id) || ''),
          meta: { comment_id: cm.id, post_id: post.id, permalink: post.permalink_url },
          messages: [cm, ...replies].map((r) => {
            const fromMe = r.from && String(r.from.id) === pageId;
            return {
              external_id: r.id,
              direction: fromMe ? 'out' : 'in',
              sender_name: fromMe ? 'You' : (r.from && r.from.name) || 'Facebook user',
              text: clip(r.message),
              attachments: [],
              sent_at: iso(r.created_time),
            };
          }),
        });
      }
    }
    return out;
  },

  async reply(conn, conv, { text, imageUrl, mode }) {
    const token = conn.token;
    if (conv.kind === 'comment' && mode !== 'private') {
      const r = await request(graph(`${conv.meta.comment_id}/comments`), { method: 'POST', platform: P, form: { message: text, access_token: token } });
      return { external_id: r.id, text };
    }
    const recipient = conv.kind === 'comment' ? { comment_id: conv.meta.comment_id } : { id: conv.participant_id };
    const message = imageUrl ? { attachment: { type: 'image', payload: { url: imageUrl, is_reusable: false } } } : { text };
    const r = await request(graph(`${conn.account_id}/messages`), {
      method: 'POST', platform: P, query: { access_token: token },
      body: { recipient, messaging_type: 'RESPONSE', message },
    });
    return { external_id: r.message_id || `sent-${Date.now()}`, text: imageUrl ? '' : text, attachments: imageUrl ? [{ type: 'image', url: imageUrl }] : [] };
  },

  link(conv) {
    if (conv.kind === 'comment') return conv.meta.permalink || 'https://www.facebook.com/';
    return 'https://business.facebook.com/latest/inbox';
  },
};
