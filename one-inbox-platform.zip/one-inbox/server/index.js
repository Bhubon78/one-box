const path = require('path');
const fs = require('fs');
const express = require('express');
const { config, check } = require('./config');
const db = require('./db');
const auth = require('./auth');
const api = require('./routes/api');
const webhooks = require('./routes/webhooks');
const sync = require('./sync');
const telegram = require('./connectors/telegram');

function createApp() {
  const app = express();
  app.disable('x-powered-by');
  app.set('trust proxy', 1); // Render puts the app behind a proxy

  // Security headers
  app.use((req, res, next) => {
    res.set({
      'Content-Security-Policy': "default-src 'self'; img-src 'self' https: data:; media-src 'self' https:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'",
      'X-Content-Type-Options': 'nosniff',
      'Referrer-Policy': 'strict-origin-when-cross-origin',
      'X-Frame-Options': 'DENY',
      'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
    });
    if (config.publicUrl.startsWith('https://')) res.set('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
    next();
  });

  // Webhooks and the cron endpoint are called by other services, so they come before the CSRF check.
  app.use('/api', webhooks);

  app.use('/api', express.json({ limit: '1mb' }));
  // CSRF protection: every state-changing call from the dashboard sends this header.
  // Browsers won't let another website add it without our permission.
  app.use('/api', (req, res, next) => {
    if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
    if (req.get('X-Requested-With') !== 'onebox') return res.status(403).json({ error: 'Blocked' });
    next();
  });
  app.use('/api', auth.loadUser);
  app.use('/api/auth', auth.router);
  app.use('/api', api);
  app.use('/api', (req, res) => res.status(404).json({ error: 'Not found' }));

  // The dashboard (built React app)
  const dist = path.join(__dirname, '..', 'web', 'dist');
  if (fs.existsSync(dist)) {
    // The service worker and manifest must always be fresh so app updates reach phones.
    app.get(['/sw.js', '/manifest.webmanifest'], (req, res, next) => {
      res.set('Cache-Control', 'no-cache');
      if (req.path.endsWith('.webmanifest')) res.type('application/manifest+json');
      next();
    });
    app.use(express.static(dist, { index: false, maxAge: '1h', setHeaders: (res, file) => { if (/sw\.js$|\.webmanifest$/.test(file)) res.set('Cache-Control', 'no-cache'); } }));
    app.get('*', (req, res) => res.sendFile(path.join(dist, 'index.html')));
  } else {
    app.get('/', (req, res) => res.send('Dashboard not built yet. Run: npm run build'));
  }

  // Errors: log details, show a simple message
  app.use((err, req, res, next) => { // eslint-disable-line no-unused-vars
    console.error(err);
    if (res.headersSent) return;
    res.status(500).json({ error: 'Something went wrong. Please try again.' });
  });
  return app;
}

async function start() {
  const problems = check();
  if (problems.length) {
    console.error('\nPlease fix your settings:\n - ' + problems.join('\n - ') + '\n');
    process.exit(1);
  }
  await db.migrate();
  const app = createApp();
  app.listen(config.port, () => {
    console.log(`\n${config.appName} is running at ${config.publicUrl} (port ${config.port})`);
    const on = Object.entries(config.enabled).filter(([, v]) => v).map(([k]) => k);
    console.log(`Platforms switched on: ${on.length ? on.join(', ') : 'none yet (add keys to your settings)'}`);
    console.log(`AI: ${config.ai.apiKey ? config.ai.model : 'off (keyword rules)'}\n`);
  });
  telegram.setupWebhook().then((m) => m !== 'off' && console.log(`Telegram: ${m}`)).catch((e) => console.error('Telegram setup failed:', e.message));
  sync.startScheduler();
}

if (require.main === module) start();

module.exports = { createApp };
