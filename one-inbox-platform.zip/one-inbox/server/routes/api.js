// Private API used by the dashboard. Every query is limited to the logged-in user's own data.
const express = require('express');
const db = require('../db');
const { config } = require('../config');
const { encrypt, randomToken } = require('../crypto');
const { requireUser } = require('../auth');
const connectors = require('../connectors');
const { syncConnection, withTokens } = require('../sync');
const ingest = require('../ingest');
const ai = require('../ai');
const push = require('../push');

const router = express.Router();
const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
const isUuid = (s) => /^[0-9a-f-]{36}$/i.test(String(s));

// Public: which platforms this server has switched on
router.get('/config', (req, res) => {
  res.json({
    appName: config.appName,
    ai: ai.enabled(),
    contactEmail: config.contactEmail,
    platforms: connectors.list.map((c) => ({ id: c.id, name: c.name, needs: c.needs, enabled: c.enabled(), capabilities: c.capabilities })),
    comingSoon: connectors.comingSoon,
  });
});

// ---------- OAuth connect flow ----------
router.get('/connect/:platform', requireUser, wrap(async (req, res) => {
  const c = connectors.byId[req.params.platform];
  if (!c || !c.enabled() || !c.authUrl) return res.redirect('/connections?error=' + encodeURIComponent('That platform is not set up on this server yet.'));
  const state = randomToken(24);
  await db.q(`insert into pending_links (code, user_id, platform) values ($1, $2, $3)`, [state, req.user.id, c.id]);
  res.redirect(c.authUrl(state));
}));

router.get('/connect/:platform/callback', requireUser, wrap(async (req, res) => {
  const c = connectors.byId[req.params.platform];
  const fail = (msg) => res.redirect('/connections?error=' + encodeURIComponent(msg));
  if (!c || !c.handleCallback) return fail('Unknown platform');
  if (req.query.error) return fail(req.query.error_description || 'Connection was cancelled.');
  // The state must match one we created for THIS user in the last 30 minutes (stops forged callbacks).
  const ok = await db.one(
    `delete from pending_links where code = $1 and user_id = $2 and platform = $3 and created_at > now() - interval '30 minutes' returning code`,
    [String(req.query.state || ''), req.user.id, c.id]);
  if (!ok) return fail('This connection link expired. Please try again.');
  let accounts;
  try {
    accounts = await c.handleCallback(req.query);
  } catch (e) {
    return fail(e.message);
  }
  for (const a of accounts) {
    const row = await db.one(
      `insert into connections (user_id, platform, account_id, account_name, avatar_url, token_enc, refresh_enc, token_expires_at, meta, status, last_error, last_sync_at)
       values ($1,$2,$3,$4,$5,$6,$7,$8,$9,'ok','',null)
       on conflict (user_id, platform, account_id) do update set
         account_name = excluded.account_name, avatar_url = excluded.avatar_url, token_enc = excluded.token_enc,
         refresh_enc = coalesce(excluded.refresh_enc, connections.refresh_enc), token_expires_at = excluded.token_expires_at,
         meta = connections.meta || excluded.meta, status = 'ok', last_error = '', last_sync_at = null
       returning *`,
      [req.user.id, c.id, a.account_id, a.account_name, a.avatar_url || '', encrypt(a.token), encrypt(a.refresh), a.expires_at, JSON.stringify(a.meta || {})]);
    syncConnection(row).catch(() => {}); // first sync in the background
  }
  res.redirect('/connections?connected=' + c.id);
}));

router.post('/connect/telegram', requireUser, wrap(async (req, res) => {
  const t = connectors.byId.telegram;
  if (!t.enabled()) return res.status(400).json({ error: 'Telegram is not set up on this server yet.' });
  res.json({ link: await t.startLink(req.user.id) });
}));

// ---------- Connections ----------
router.get('/connections', requireUser, wrap(async (req, res) => {
  const r = await db.q(
    `select c.id, c.platform, c.account_id, c.account_name, c.avatar_url, c.status, c.last_error, c.last_sync_at, c.created_at,
            (c.meta->>'business_connection_id') is not null as business,
            (select followers from stats s where s.connection_id = c.id order by day desc limit 1) as followers
     from connections c where c.user_id = $1 order by c.created_at`, [req.user.id]);
  res.json(r.rows);
}));

router.post('/connections/:id/sync', requireUser, wrap(async (req, res) => {
  if (!isUuid(req.params.id)) return res.status(404).json({ error: 'Not found' });
  const row = await db.one(`select * from connections where id = $1 and user_id = $2`, [req.params.id, req.user.id]);
  if (!row) return res.status(404).json({ error: 'Not found' });
  const r = await syncConnection(row);
  if (r.error) return res.status(502).json({ error: r.error });
  res.json({ ok: true, newMessages: r.newInbound || 0 });
}));

router.delete('/connections/:id', requireUser, wrap(async (req, res) => {
  if (!isUuid(req.params.id)) return res.status(404).json({ error: 'Not found' });
  const r = await db.q(`delete from connections where id = $1 and user_id = $2`, [req.params.id, req.user.id]);
  if (!r.rowCount) return res.status(404).json({ error: 'Not found' });
  res.json({ ok: true });
}));

// ---------- Overview ----------
router.get('/overview', requireUser, wrap(async (req, res) => {
  const uid = req.user.id;
  const totals = await db.one(
    `select count(*) filter (where needs_reply and not archived)::int as needs_reply,
            count(*) filter (where urgent and needs_reply and not archived)::int as urgent,
            count(*) filter (where category = 'brand_deal' and not archived)::int as brand_deals,
            count(*) filter (where unread and not archived)::int as unread
     from conversations where user_id = $1`, [uid]);
  const byPlatform = (await db.q(
    `select platform, count(*) filter (where unread and not archived)::int as unread,
            count(*) filter (where needs_reply and not archived)::int as needs_reply,
            count(*) filter (where kind = 'comment')::int as comments, count(*) filter (where kind <> 'comment')::int as messages
     from conversations where user_id = $1 group by platform`, [uid])).rows;
  const byCategory = (await db.q(
    `select category, count(*)::int as n,
            (array_agg(participant_name order by last_message_at desc) filter (where participant_name <> ''))[1:3] as names
     from conversations where user_id = $1 and not archived and category <> '' group by category order by n desc`, [uid])).rows;
  const accounts = (await db.q(
    `select c.id, c.platform, c.account_name, c.avatar_url, c.status,
            coalesce((select json_agg(json_build_object('day', s.day, 'followers', s.followers) order by s.day)
                      from (select day, followers from stats where connection_id = c.id order by day desc limit 30) s), '[]') as trend,
            (select metrics from stats where connection_id = c.id order by day desc limit 1) as metrics
     from connections c where c.user_id = $1 order by c.created_at`, [uid])).rows;
  const activity = (await db.q(
    `select to_char(date_trunc('day', m.sent_at), 'YYYY-MM-DD') as day, count(*)::int as n
     from messages m where m.user_id = $1 and m.direction = 'in' and m.sent_at > now() - interval '14 days'
     group by 1 order by 1`, [uid])).rows;
  const top = (await db.q(
    `select id, platform, kind, title, participant_name, last_preview, last_message_at, category, urgent, ai_reason
     from conversations where user_id = $1 and needs_reply and not archived
     order by urgent desc, (category = 'brand_deal') desc, last_message_at desc limit 6`, [uid])).rows;
  res.json({ totals, byPlatform, byCategory, accounts, activity, top });
}));

// ---------- Inbox ----------
router.get('/conversations', requireUser, wrap(async (req, res) => {
  const where = ['user_id = $1'];
  const params = [req.user.id];
  const add = (sql, v) => { params.push(v); where.push(sql.replace('?', '$' + params.length)); };
  const { platform, filter, q, before } = req.query;
  if (platform && connectors.byId[platform]) add('platform = ?', platform);
  if (req.query.category && ai.CATEGORIES.includes(req.query.category)) add('category = ?', req.query.category);
  switch (filter) {
    case 'needs_reply': where.push('needs_reply and not archived'); break;
    case 'urgent': where.push('urgent and needs_reply and not archived'); break;
    case 'brand_deal': where.push(`category in ('brand_deal','collab') and not archived`); break;
    case 'unread': where.push('unread and not archived'); break;
    case 'comments': where.push(`kind = 'comment' and not archived`); break;
    case 'archived': where.push('archived'); break;
    default: where.push('not archived');
  }
  if (q && String(q).trim()) {
    params.push('%' + String(q).trim().slice(0, 100).replace(/[%_\\]/g, '\\$&') + '%');
    const p = '$' + params.length;
    where.push(`(title ilike ${p} or participant_name ilike ${p} or exists (select 1 from messages m where m.conversation_id = conversations.id and m.text ilike ${p}))`);
  }
  if (before && !isNaN(Date.parse(before))) add('last_message_at < ?', before);
  const r = await db.q(
    `select id, platform, kind, title, participant_name, last_preview, last_message_at, unread, needs_reply, category, urgent, archived
     from conversations where ${where.join(' and ')} order by last_message_at desc limit 50`, params);
  res.json(r.rows);
}));

async function ownConversation(req) {
  if (!isUuid(req.params.id)) return null;
  return db.one(`select * from conversations where id = $1 and user_id = $2`, [req.params.id, req.user.id]);
}

router.get('/conversations/:id', requireUser, wrap(async (req, res) => {
  const conv = await ownConversation(req);
  if (!conv) return res.status(404).json({ error: 'Not found' });
  const msgs = (await db.q(`select id, external_id, direction, sender_name, text, attachments, sent_at from messages where conversation_id = $1 order by sent_at, id limit 200`, [conv.id])).rows;
  if (conv.unread) await db.q(`update conversations set unread = false where id = $1`, [conv.id]);
  const c = connectors.byId[conv.platform];
  const lastIn = [...msgs].reverse().find((m) => m.direction === 'in');
  const windowH = c && c.capabilities.replyWindowHours;
  const windowOpen = !(windowH && conv.kind === 'dm' && lastIn && Date.now() - new Date(lastIn.sent_at) > windowH * 3600e3);
  const canReply = conv.platform !== 'telegram' || (!!conv.meta.business_connection_id && !conv.meta.forwarded);
  res.json({
    conversation: { ...conv, unread: false },
    messages: msgs,
    capabilities: c ? c.capabilities : {},
    link: c && c.link ? c.link(conv) : null,
    windowOpen,
    canReply,
  });
}));

router.patch('/conversations/:id', requireUser, wrap(async (req, res) => {
  const conv = await ownConversation(req);
  if (!conv) return res.status(404).json({ error: 'Not found' });
  const b = req.body || {};
  const sets = [];
  const params = [conv.id];
  const set = (col, v) => { params.push(v); sets.push(`${col} = $${params.length}`); };
  if (typeof b.archived === 'boolean') set('archived', b.archived);
  if (typeof b.unread === 'boolean') set('unread', b.unread);
  if (typeof b.needs_reply === 'boolean') set('needs_reply', b.needs_reply);
  if (typeof b.urgent === 'boolean') set('urgent', b.urgent);
  if (typeof b.category === 'string' && ai.CATEGORIES.includes(b.category)) set('category', b.category);
  if (!sets.length) return res.status(400).json({ error: 'Nothing to change' });
  await db.q(`update conversations set ${sets.join(', ')} where id = $1`, params);
  res.json({ ok: true });
}));

router.post('/conversations/:id/reply', requireUser, wrap(async (req, res) => {
  const conv = await ownConversation(req);
  if (!conv) return res.status(404).json({ error: 'Not found' });
  const text = String((req.body && req.body.text) || '').trim();
  const imageUrl = String((req.body && req.body.imageUrl) || '').trim();
  const mode = req.body && req.body.mode === 'private' ? 'private' : 'public';
  if (!text && !imageUrl) return res.status(400).json({ error: 'Write a reply first' });
  if (text.length > 1000) return res.status(400).json({ error: 'Keep replies under 1000 characters' });
  if (imageUrl && !/^https:\/\/\S+$/i.test(imageUrl)) return res.status(400).json({ error: 'Image link must start with https://' });
  const c = connectors.byId[conv.platform];
  const row = await db.one(`select * from connections where id = $1 and user_id = $2`, [conv.connection_id, req.user.id]);
  if (!c || !row) return res.status(400).json({ error: 'This account is no longer connected' });
  if (imageUrl && !c.capabilities.image) return res.status(400).json({ error: `${c.name} doesn't support sending images from here` });
  const conn = withTokens(row);
  if (c.refresh) {
    const r = await c.refresh(conn).catch(() => null);
    if (r && r.token) {
      conn.token = r.token;
      await db.q(`update connections set token_enc = $2, token_expires_at = $3 where id = $1`, [conn.id, encrypt(r.token), r.expires_at]);
    }
  }
  let sent;
  try {
    sent = await c.reply(conn, conv, { text, imageUrl: imageUrl || null, mode });
  } catch (e) {
    return res.status(e.status && e.status < 500 ? e.status : 502).json({ error: e.message });
  }
  // Private replies to a comment go to the person's DMs; keep a note on the comment thread.
  await ingest.saveConversations(conn, [{
    external_id: conv.external_id, kind: conv.kind, title: conv.title, participant_name: conv.participant_name, participant_id: conv.participant_id, meta: {},
    messages: [{ external_id: sent.external_id, direction: 'out', sender_name: 'You', text: (mode === 'private' && conv.kind === 'comment' ? '(sent privately) ' : '') + (sent.text || ''), attachments: sent.attachments || [], sent_at: new Date().toISOString() }],
  }]);
  await db.q(`update conversations set needs_reply = false, unread = false where id = $1`, [conv.id]);
  res.json({ ok: true });
}));

router.post('/conversations/:id/react', requireUser, wrap(async (req, res) => {
  const conv = await ownConversation(req);
  if (!conv) return res.status(404).json({ error: 'Not found' });
  const c = connectors.byId[conv.platform];
  if (!c || !c.react) return res.status(400).json({ error: 'Reactions are not available for this platform' });
  const emoji = String((req.body && req.body.emoji) || '');
  if (!['❤️', '😂', '😮', '😢', '😡', '👍', '🔥', '🙏'].includes(emoji)) return res.status(400).json({ error: 'Pick one of the listed reactions' });
  const msg = await db.one(`select external_id from messages where id = $1 and conversation_id = $2`, [String((req.body && req.body.messageId) || ''), conv.id]).catch(() => null);
  if (!msg) return res.status(404).json({ error: 'Message not found' });
  const row = await db.one(`select * from connections where id = $1 and user_id = $2`, [conv.connection_id, req.user.id]);
  try {
    await c.react(withTokens(row), conv, msg.external_id, emoji);
  } catch (e) {
    return res.status(502).json({ error: e.message });
  }
  res.json({ ok: true });
}));

router.post('/conversations/:id/suggest', requireUser, wrap(async (req, res) => {
  const conv = await ownConversation(req);
  if (!conv) return res.status(404).json({ error: 'Not found' });
  const msgs = (await db.q(`select direction, sender_name, text from messages where conversation_id = $1 order by sent_at desc limit 8`, [conv.id])).rows.reverse();
  const user = await db.one(`select settings from users where id = $1`, [req.user.id]);
  let reply;
  try {
    reply = await ai.suggest(conv, msgs, req.body && req.body.instruction, user.settings.about);
  } catch (e) {
    return res.status(502).json({ error: 'The AI could not write a reply just now.' });
  }
  await db.q(`update conversations set ai_reply = $2 where id = $1`, [conv.id, reply]);
  res.json({ reply });
}));

// ---------- Settings ----------
router.get('/settings', requireUser, wrap(async (req, res) => {
  const u = await db.one(`select email, name, settings from users where id = $1`, [req.user.id]);
  const devices = await db.one(`select count(*)::int as n from push_subscriptions where user_id = $1`, [req.user.id]);
  res.json({ email: u.email, name: u.name, about: u.settings.about || '', notify: u.settings.notify || 'important', devices: devices.n });
}));
router.put('/settings', requireUser, wrap(async (req, res) => {
  const name = String((req.body && req.body.name) || '').trim().slice(0, 80);
  const about = String((req.body && req.body.about) || '').trim().slice(0, 1000);
  const patch = { about };
  if (['important', 'all', 'off'].includes(req.body && req.body.notify)) patch.notify = req.body.notify;
  await db.q(`update users set name = $2, settings = settings || $3 where id = $1`, [req.user.id, name, JSON.stringify(patch)]);
  res.json({ ok: true });
}));

// ---------- Notifications ----------
router.get('/push/key', requireUser, wrap(async (req, res) => res.json({ key: await push.publicKey() })));
router.post('/push/subscribe', requireUser, wrap(async (req, res) => {
  try {
    await push.subscribe(req.user.id, req.body && req.body.subscription, req.get('user-agent'));
  } catch (e) {
    return res.status(e.status || 500).json({ error: e.message });
  }
  res.json({ ok: true });
}));
router.post('/push/unsubscribe', requireUser, wrap(async (req, res) => {
  await push.unsubscribe(req.user.id, req.body && req.body.endpoint);
  res.json({ ok: true });
}));
router.post('/push/test', requireUser, wrap(async (req, res) => {
  const sent = await push.notifyUser(req.user.id, { title: 'Notifications are on', body: 'You\'ll hear about brand deals and urgent messages here.', url: '/overview', tag: 'test' });
  if (!sent) return res.status(400).json({ error: 'No device is set up for notifications yet.' });
  res.json({ ok: true, sent });
}));

module.exports = router;
