// Endpoints called by other services (not by the dashboard).
const express = require('express');
const crypto = require('crypto');
const db = require('../db');
const { config } = require('../config');
const { safeEqual, randomToken } = require('../crypto');
const telegram = require('../connectors/telegram');
const { tick } = require('../sync');

const router = express.Router();

// Telegram sends every new message here.
router.post('/webhooks/telegram', express.json({ limit: '1mb' }), async (req, res) => {
  if (!telegram.enabled() || !telegram.checkSecret(req.get('X-Telegram-Bot-Api-Secret-Token'))) return res.sendStatus(401);
  res.sendStatus(200); // answer fast; Telegram retries slow webhooks
  telegram.handleUpdate(req.body || {}).catch((e) => console.error('Telegram update failed:', e.message));
});

// A free scheduler (cron-job.org or GitHub Actions) calls this every few minutes.
// It keeps the free server awake and triggers syncing.
router.all('/cron', async (req, res) => {
  const key = req.query.key || req.get('X-Cron-Key') || '';
  if (!config.cronSecret || !safeEqual(key, config.cronSecret)) return res.sendStatus(401);
  try {
    res.json(await tick());
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

router.get('/health', async (req, res) => {
  try {
    await db.q('select 1');
    res.json({ ok: true });
  } catch {
    res.status(503).json({ ok: false });
  }
});

// Meta requires a "data deletion callback": when someone removes the app from their
// Facebook/Instagram settings, Meta tells us and we delete their data.
function parseSignedRequest(signed, secret) {
  const [sig, payload] = String(signed || '').split('.');
  if (!sig || !payload || !secret) return null;
  const expected = crypto.createHmac('sha256', secret).update(payload).digest('base64url');
  if (!safeEqual(sig, expected)) return null;
  try {
    return JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
  } catch {
    return null;
  }
}
router.post('/meta/data-deletion', express.urlencoded({ extended: false }), async (req, res) => {
  const data = parseSignedRequest(req.body.signed_request, config.meta.appSecret) || parseSignedRequest(req.body.signed_request, config.meta.igAppSecret);
  if (!data || !data.user_id) return res.status(400).json({ error: 'Invalid request' });
  await db.q(`delete from connections where platform in ('instagram','facebook') and (account_id = $1 or meta->>'app_scoped_id' = $1)`, [String(data.user_id)]);
  const code = randomToken(9);
  res.json({ url: `${config.publicUrl}/data-deletion?code=${code}`, confirmation_code: code });
});
// Meta also calls this when someone removes the app; treat it the same way.
router.post('/meta/deauthorize', express.urlencoded({ extended: false }), async (req, res) => {
  const data = parseSignedRequest(req.body.signed_request, config.meta.appSecret) || parseSignedRequest(req.body.signed_request, config.meta.igAppSecret);
  if (data && data.user_id) {
    await db.q(`update connections set status = 'reconnect', last_error = 'Access was removed in Meta settings' where platform in ('instagram','facebook') and (account_id = $1 or meta->>'app_scoped_id' = $1)`, [String(data.user_id)]);
  }
  res.sendStatus(200);
});

module.exports = router;
