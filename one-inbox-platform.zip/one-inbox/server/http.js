// Small wrapper around fetch for calling platform APIs, with readable errors.
class ApiError extends Error {
  constructor(message, { status, platform, code, needsReconnect } = {}) {
    super(message);
    this.status = status;
    this.platform = platform;
    this.code = code;
    this.needsReconnect = !!needsReconnect;
  }
}

async function request(url, { method = 'GET', headers = {}, body, form, query, platform, timeoutMs = 20000 } = {}) {
  const u = new URL(url);
  if (query) for (const [k, v] of Object.entries(query)) if (v !== undefined && v !== null) u.searchParams.set(k, String(v));
  const opts = { method, headers: { ...headers }, signal: AbortSignal.timeout(timeoutMs) };
  if (form) {
    opts.body = new URLSearchParams(Object.entries(form).filter(([, v]) => v !== undefined));
    opts.headers['Content-Type'] = 'application/x-www-form-urlencoded';
  } else if (body !== undefined) {
    opts.body = JSON.stringify(body);
    opts.headers['Content-Type'] = 'application/json';
  }
  let res;
  try {
    res = await fetch(u, opts);
  } catch (e) {
    throw new ApiError(`${platform || 'Platform'} could not be reached (${e.name === 'TimeoutError' ? 'timed out' : e.message})`, { platform });
  }
  const text = await res.text();
  let data;
  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    data = { raw: text };
  }
  if (!res.ok || (data && data.error && typeof data.error === 'object' && data.error.message)) {
    const err = data.error || {};
    const msg = (typeof err === 'object' ? err.message || err.error_user_msg : data.error_description || err) || data.error_message || data.description || data.error_description || `HTTP ${res.status}`;
    const code = typeof err === 'object' ? err.code : undefined;
    // 190 = Meta expired/invalid token, 401 = Google/others, invalid_grant = Google refresh revoked
    const needsReconnect = res.status === 401 || code === 190 || err.status === 'UNAUTHENTICATED' || data.error === 'invalid_grant';
    throw new ApiError(`${platform || 'Platform'}: ${msg}`, { status: res.status, platform, code, needsReconnect });
  }
  return data;
}

module.exports = { request, ApiError };
