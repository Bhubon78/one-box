// Sign up, log in, log out, and the session check used by every private API route.
const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('./db');
const { config } = require('./config');
const { randomToken, sha256 } = require('./crypto');

const COOKIE = 'ob_session';
const SESSION_DAYS = 30;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
let DUMMY;
const dummyHash = () => (DUMMY ||= bcrypt.hashSync('not-a-real-password', 12));

function cookieOptions(maxAgeMs) {
  return {
    httpOnly: true,                 // JavaScript in the page can't read it
    secure: config.publicUrl.startsWith('https://'),
    sameSite: 'lax',                // blocks cross-site form posts
    path: '/',
    maxAge: maxAgeMs,
  };
}

function readCookie(req, name) {
  const raw = req.headers.cookie || '';
  for (const part of raw.split(';')) {
    const [k, ...v] = part.trim().split('=');
    if (k === name) return decodeURIComponent(v.join('='));
  }
  return null;
}

async function createSession(res, userId) {
  const token = randomToken(32);
  const expires = new Date(Date.now() + SESSION_DAYS * 864e5);
  await db.q('insert into sessions (id, user_id, expires_at) values ($1, $2, $3)', [sha256(token), userId, expires]);
  res.cookie(COOKIE, token, cookieOptions(SESSION_DAYS * 864e5));
}

// Attaches req.user when the session cookie is valid.
async function loadUser(req, res, next) {
  const token = readCookie(req, COOKIE);
  if (!token) return next();
  try {
    const row = await db.one(
      `select u.id, u.email, u.name from sessions s join users u on u.id = s.user_id
       where s.id = $1 and s.expires_at > now()`,
      [sha256(token)]
    );
    if (row) req.user = row;
  } catch (e) {
    return next(e);
  }
  next();
}

function requireUser(req, res, next) {
  if (!req.user) return res.status(401).json({ error: 'Please log in' });
  next();
}

// Simple brute-force protection stored in the database (works across restarts).
async function checkLock(key) {
  const row = await db.one('select count, locked_until from login_attempts where key = $1', [key]);
  return row && row.locked_until && new Date(row.locked_until) > new Date();
}
async function recordFail(key) {
  await db.q(
    `insert into login_attempts (key, count) values ($1, 1)
     on conflict (key) do update set count = login_attempts.count + 1,
       locked_until = case when login_attempts.count + 1 >= 8 then now() + interval '15 minutes' else null end`,
    [key]
  );
  await db.q(`update login_attempts set count = 0 where key = $1 and count >= 8`, [key]);
}
const clearFails = (key) => db.q('delete from login_attempts where key = $1', [key]);

const router = express.Router();

router.post('/signup', async (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  const name = String(req.body.name || '').trim().slice(0, 80);
  if (!EMAIL_RE.test(email) || email.length > 200) return res.status(400).json({ error: 'Enter a valid email address' });
  if (password.length < 10) return res.status(400).json({ error: 'Use a password with at least 10 characters' });
  if (password.length > 200) return res.status(400).json({ error: 'That password is too long' });
  const exists = await db.one('select 1 from users where lower(email) = $1', [email]);
  if (exists) return res.status(409).json({ error: 'An account with this email already exists. Log in instead.' });
  const hash = await bcrypt.hash(password, 12);
  const user = await db.one('insert into users (email, password_hash, name) values ($1, $2, $3) returning id, email, name', [email, hash, name]);
  await createSession(res, user.id);
  res.json({ user });
});

router.post('/login', async (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  const key = 'login:' + email;
  if (await checkLock(key)) return res.status(429).json({ error: 'Too many attempts. Try again in 15 minutes.' });
  const user = await db.one('select id, email, name, password_hash from users where lower(email) = $1', [email]);
  // Compare even when the user doesn't exist, so response time doesn't reveal which emails are registered.
  const ok = await bcrypt.compare(password, user ? user.password_hash : dummyHash());
  if (!user || !ok) {
    await recordFail(key);
    return res.status(401).json({ error: 'Wrong email or password' });
  }
  await clearFails(key);
  await createSession(res, user.id);
  res.json({ user: { id: user.id, email: user.email, name: user.name } });
});

router.post('/logout', async (req, res) => {
  const token = readCookie(req, COOKIE);
  if (token) await db.q('delete from sessions where id = $1', [sha256(token)]);
  res.clearCookie(COOKIE, { path: '/' });
  res.json({ ok: true });
});

router.get('/me', (req, res) => {
  res.json({ user: req.user || null });
});

router.post('/delete-account', requireUser, async (req, res) => {
  const row = await db.one('select password_hash from users where id = $1', [req.user.id]);
  if (!row || !(await bcrypt.compare(String(req.body.password || ''), row.password_hash))) {
    return res.status(401).json({ error: 'Wrong password' });
  }
  await db.q('delete from users where id = $1', [req.user.id]); // cascades to everything
  res.clearCookie(COOKIE, { path: '/' });
  res.json({ ok: true });
});

module.exports = { router, loadUser, requireUser };
