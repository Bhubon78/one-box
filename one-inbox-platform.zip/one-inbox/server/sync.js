// Automatic syncing: every minute, accounts that haven't synced for SYNC_EVERY_MINUTES are refreshed.
const db = require('./db');
const { config } = require('./config');
const { encrypt, decrypt } = require('./crypto');
const connectors = require('./connectors');
const ingest = require('./ingest');
const ai = require('./ai');

const ctx = {
  async knownMessageIds(connectionId) {
    const r = await db.q(
      `select m.external_id from messages m join conversations c on c.id = m.conversation_id
       where c.connection_id = $1 and m.sent_at > now() - interval '45 days'`, [connectionId]);
    return new Set(r.rows.map((x) => x.external_id));
  },
};

function withTokens(row) {
  return { ...row, meta: row.meta || {}, token: decrypt(row.token_enc), refresh: decrypt(row.refresh_enc) };
}

async function syncConnection(row) {
  const c = connectors.byId[row.platform];
  if (!c || !c.enabled()) return { skipped: true };
  const conn = withTokens(row);
  try {
    if (c.refresh) {
      const r = await c.refresh(conn);
      if (r && r.token) {
        conn.token = r.token;
        if (r.refresh) conn.refresh = r.refresh;
        conn.token_expires_at = r.expires_at;
        await db.q(`update connections set token_enc = $2, refresh_enc = coalesce($3, refresh_enc), token_expires_at = $4 where id = $1`,
          [conn.id, encrypt(r.token), r.refresh ? encrypt(r.refresh) : null, r.expires_at]);
      }
    }
    const result = await c.sync(conn, ctx);
    const { newInbound } = await ingest.saveConversations(conn, result.conversations);
    await ingest.saveStats(conn, result.stats);
    await db.q(`update connections set last_sync_at = now(), status = 'ok', last_error = '', avatar_url = coalesce(nullif($2, ''), avatar_url) where id = $1`,
      [conn.id, result.avatar_url || '']);
    if (newInbound) await ai.triageUser(conn.user_id).catch((e) => console.warn('Triage failed:', e.message));
    return { newInbound };
  } catch (e) {
    const status = e.needsReconnect ? 'reconnect' : 'error';
    await db.q(`update connections set last_sync_at = now(), status = $2, last_error = $3 where id = $1`, [conn.id, status, String(e.message).slice(0, 300)]);
    console.warn(`Sync ${row.platform} ${row.account_name} failed:`, e.message);
    return { error: e.message };
  }
}

let running = false;
async function tick() {
  if (running) return { busy: true };
  running = true;
  const client = await db.getPool().connect();
  let done = 0;
  try {
    // Only one server instance syncs at a time.
    const { rows } = await client.query('select pg_try_advisory_lock(424242) as ok');
    if (!rows[0].ok) return { busy: true };
    try {
      const due = (await db.q(
        `select * from connections
         where platform <> 'telegram' and status <> 'reconnect'
           and (last_sync_at is null or last_sync_at < now() - ($1 || ' minutes')::interval)
         order by last_sync_at nulls first limit 30`, [String(config.syncEveryMinutes)])).rows;
      for (let i = 0; i < due.length; i += 3) {
        await Promise.all(due.slice(i, i + 3).map(syncConnection));
        done += Math.min(3, due.length - i);
      }
      await db.q(`delete from pending_links where created_at < now() - interval '1 hour'`);
      await db.q(`delete from sessions where expires_at < now()`);
    } finally {
      await client.query('select pg_advisory_unlock(424242)');
    }
  } finally {
    client.release();
    running = false;
  }
  return { synced: done };
}

let timer;
function startScheduler() {
  timer = setInterval(() => tick().catch((e) => console.error('Sync tick failed:', e.message)), 60e3);
  setTimeout(() => tick().catch(() => {}), 5000);
}
connectors.byId.telegram.setOnNewMessages((userId) => ai.triageUser(userId).catch(() => {}));
const stopScheduler = () => clearInterval(timer);

module.exports = { tick, syncConnection, startScheduler, stopScheduler, withTokens };
