// All settings come from environment variables (see .env.example).
require('dotenv').config({ quiet: true });

const env = (k, d = '') => (process.env[k] ?? d).trim();
const PUBLIC_URL = env('PUBLIC_URL', 'http://localhost:3000').replace(/\/$/, '');

const config = {
  appName: env('APP_NAME', 'One Inbox'),
  port: Number(env('PORT', '3000')),
  publicUrl: PUBLIC_URL,
  isProd: env('NODE_ENV') === 'production',
  databaseUrl: env('DATABASE_URL'),
  // 32+ random characters. Encrypts every platform token stored in the database.
  encryptionKey: env('ENCRYPTION_KEY'),
  // Protects the /api/cron endpoint that a free scheduler calls.
  cronSecret: env('CRON_SECRET'),
  syncEveryMinutes: Number(env('SYNC_EVERY_MINUTES', '5')),
  contactEmail: env('CONTACT_EMAIL', 'privacy@example.com'),

  ai: {
    apiKey: env('ANTHROPIC_API_KEY'),
    model: env('AI_MODEL', 'claude-haiku-5-5'),
  },

  meta: {
    graphVersion: env('META_GRAPH_VERSION', 'v25.0'),
    // Facebook Login (Pages + Messenger)
    appId: env('META_APP_ID'),
    appSecret: env('META_APP_SECRET'),
    // Instagram API with Instagram Login (separate ID/secret shown under Instagram > API setup)
    igAppId: env('INSTAGRAM_APP_ID'),
    igAppSecret: env('INSTAGRAM_APP_SECRET'),
  },

  google: {
    clientId: env('GOOGLE_CLIENT_ID'),
    clientSecret: env('GOOGLE_CLIENT_SECRET'),
  },

  telegram: {
    botToken: env('TELEGRAM_BOT_TOKEN'),
    botUsername: env('TELEGRAM_BOT_USERNAME').replace(/^@/, ''),
    // Telegram only accepts letters, numbers, _ and - in this secret.
    webhookSecret: env('TELEGRAM_WEBHOOK_SECRET').replace(/[^A-Za-z0-9_-]/g, '').slice(0, 256),
  },

  // API hosts. Only changed by the automated tests, which point them at a fake server.
  hosts: {
    graphFacebook: env('HOST_GRAPH_FACEBOOK', 'https://graph.facebook.com'),
    graphInstagram: env('HOST_GRAPH_INSTAGRAM', 'https://graph.instagram.com'),
    apiInstagram: env('HOST_API_INSTAGRAM', 'https://api.instagram.com'),
    wwwInstagram: env('HOST_WWW_INSTAGRAM', 'https://www.instagram.com'),
    wwwFacebook: env('HOST_WWW_FACEBOOK', 'https://www.facebook.com'),
    googleAccounts: env('HOST_GOOGLE_ACCOUNTS', 'https://accounts.google.com'),
    googleOauth: env('HOST_GOOGLE_OAUTH', 'https://oauth2.googleapis.com'),
    googleApis: env('HOST_GOOGLE_APIS', 'https://www.googleapis.com'),
    gmail: env('HOST_GMAIL', 'https://gmail.googleapis.com'),
    telegram: env('HOST_TELEGRAM', 'https://api.telegram.org'),
  },
};

// Which platforms are switched on depends on which keys are filled in.
config.enabled = {
  instagram: !!(config.meta.igAppId && config.meta.igAppSecret),
  facebook: !!(config.meta.appId && config.meta.appSecret),
  youtube: !!(config.google.clientId && config.google.clientSecret),
  gmail: !!(config.google.clientId && config.google.clientSecret),
  telegram: !!(config.telegram.botToken && config.telegram.botUsername),
};

function check() {
  const problems = [];
  if (!config.databaseUrl) problems.push('DATABASE_URL is missing (your Supabase connection string).');
  if (config.encryptionKey.length < 32) problems.push('ENCRYPTION_KEY must be at least 32 characters.');
  if (config.isProd && !config.publicUrl.startsWith('https://')) problems.push('PUBLIC_URL must start with https:// in production.');
  return problems;
}

module.exports = { config, check };
