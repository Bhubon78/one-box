-- One Inbox database. Runs automatically when the server starts.

create extension if not exists pgcrypto;

create table if not exists users (
  id            uuid primary key default gen_random_uuid(),
  email         text not null,
  password_hash text not null,
  name          text not null default '',
  settings      jsonb not null default '{}'::jsonb,  -- e.g. "about me" text for AI replies
  created_at    timestamptz not null default now()
);
create unique index if not exists users_email_lower on users (lower(email));

create table if not exists sessions (
  id          text primary key,              -- SHA-256 of the cookie token, never the token itself
  user_id     uuid not null references users(id) on delete cascade,
  expires_at  timestamptz not null,
  created_at  timestamptz not null default now()
);
create index if not exists sessions_user on sessions (user_id);

-- One row per connected account (an Instagram account, a Facebook Page, a YouTube channel ...)
create table if not exists connections (
  id               uuid primary key default gen_random_uuid(),
  user_id          uuid not null references users(id) on delete cascade,
  platform         text not null,
  account_id       text not null,
  account_name     text not null default '',
  avatar_url       text not null default '',
  token_enc        text,                      -- encrypted with ENCRYPTION_KEY
  refresh_enc      text,                      -- encrypted with ENCRYPTION_KEY
  token_expires_at timestamptz,
  meta             jsonb not null default '{}'::jsonb,
  status           text not null default 'ok', -- ok | error | reconnect
  last_error       text not null default '',
  last_sync_at     timestamptz,
  created_at       timestamptz not null default now(),
  unique (user_id, platform, account_id)
);
create index if not exists connections_due on connections (last_sync_at);

create table if not exists conversations (
  id                uuid primary key default gen_random_uuid(),
  user_id           uuid not null references users(id) on delete cascade,
  connection_id     uuid not null references connections(id) on delete cascade,
  platform          text not null,
  kind              text not null,             -- dm | comment | email
  external_id       text not null,
  title             text not null default '',
  participant_name  text not null default '',
  participant_id    text not null default '',
  last_message_at   timestamptz not null default now(),
  last_preview      text not null default '',
  unread            boolean not null default true,
  needs_reply       boolean not null default false,
  category          text not null default '',  -- fan | brand_deal | collab | question | support | spam | other
  urgent            boolean not null default false,
  ai_reason         text not null default '',
  ai_reply          text not null default '',
  archived          boolean not null default false,
  meta              jsonb not null default '{}'::jsonb,
  unique (connection_id, external_id)
);
create index if not exists conversations_inbox on conversations (user_id, archived, last_message_at desc);

create table if not exists messages (
  id               uuid primary key default gen_random_uuid(),
  conversation_id  uuid not null references conversations(id) on delete cascade,
  user_id          uuid not null references users(id) on delete cascade,
  external_id      text not null,
  direction        text not null,              -- in | out
  sender_name      text not null default '',
  text             text not null default '',
  attachments      jsonb not null default '[]'::jsonb,
  sent_at          timestamptz not null default now(),
  triaged          boolean not null default false,
  unique (conversation_id, external_id)
);
create index if not exists messages_thread on messages (conversation_id, sent_at);
create index if not exists messages_untriaged on messages (user_id) where triaged = false and direction = 'in';

-- Daily follower / audience numbers for the overview charts
create table if not exists stats (
  connection_id uuid not null references connections(id) on delete cascade,
  day           date not null,
  followers     bigint,
  metrics       jsonb not null default '{}'::jsonb,
  primary key (connection_id, day)
);

-- Short-lived values for OAuth "state" and Telegram link codes
create table if not exists pending_links (
  code        text primary key,
  user_id     uuid not null references users(id) on delete cascade,
  platform    text not null,
  created_at  timestamptz not null default now()
);

create table if not exists login_attempts (
  key         text primary key,
  count       int not null default 0,
  locked_until timestamptz
);
