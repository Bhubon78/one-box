// Notifications on iPhone (iOS 16.4+, app added to the home screen), Android and desktop browsers.
// Uses the Web Push standard. The signing keys are created automatically the first time.
const webpush = require('web-push');
const db = require('./db');
const { config } = require('./config');

let keys = null;

async function getKeys() {
  if (keys) return keys;
  if (process.env.VAPID_PUBLIC_KEY && process.env.VAPID_PRIVATE_KEY) {
    keys = { publicKey: process.env.VAPID_PUBLIC_KEY.trim(), privateKey: process.env.VAPID_PRIVATE_KEY.trim() };
  } else {
    const row = await db.one(`select value from app_settings where key = 'vapid'`);
    if (row) keys = row.value;
    else {
      const k = webpush.generateVAPIDKeys();
      // "do nothing" on conflict: if two servers start at once, both end up with the same saved keys
      await db.q(`insert into app_settings (key, value) values ('vapid', $1) on conflict (key) do nothing`, [JSON.stringify(k)]);
      keys = (await db.one(`select value from app_settings where key = 'vapid'`)).value;
    }
  }
  webpush.setVapidDetails(`mailto:${config.contactEmail}`, keys.publicKey, keys.privateKey);
  return keys;
}

async function publicKey() {
  return (await getKeys()).publicKey;
}

function validSubscription(s) {
  if (!s || typeof s !== 'object' || !s.keys) return false;
  let u;
  try {
    u = new URL(s.endpoint);
  } catch {
    return false;
  }
  if (u.protocol !== 'https:') return false;
  return typeof s.keys.p256dh === 'string' && typeof s.keys.auth === 'string' && s.keys.p256dh.length < 200 && s.keys.auth.length < 100;
}

async function subscribe(userId, sub, device) {
  if (!validSubscription(sub)) throw Object.assign(new Error('Invalid notification subscription'), { status: 400 });
  await db.q(
    `insert into push_subscriptions (user_id, endpoint, p256dh, auth, device) values ($1,$2,$3,$4,$5)
     on conflict (endpoint) do update set user_id = excluded.user_id, p256dh = excluded.p256dh, auth = excluded.auth, device = excluded.device`,
    [userId, sub.endpoint, sub.keys.p256dh, sub.keys.auth, String(device || '').slice(0, 120)]
  );
  // Keep the 10 newest devices per person
  await db.q(`delete from push_subscriptions where user_id = $1 and id not in (select id from push_subscriptions where user_id = $1 order by created_at desc limit 10)`, [userId]);
}

const unsubscribe = (userId, endpoint) => db.q(`delete from push_subscriptions where user_id = $1 and endpoint = $2`, [userId, String(endpoint || '')]);

// Send one notification to every device the person turned notifications on for.
async function notifyUser(userId, payload) {
  const subs = (await db.q(`select id, endpoint, p256dh, auth from push_subscriptions where user_id = $1`, [userId])).rows;
  if (!subs.length) return 0;
  await getKeys();
  let sent = 0;
  await Promise.all(subs.map(async (s) => {
    try {
      await webpush.sendNotification({ endpoint: s.endpoint, keys: { p256dh: s.p256dh, auth: s.auth } }, JSON.stringify(payload), { TTL: 3600, urgency: 'high' });
      sent++;
      await db.q(`update push_subscriptions set last_used_at = now() where id = $1`, [s.id]);
    } catch (e) {
      // 404/410: the phone removed the app or turned notifications off
      if (e.statusCode === 404 || e.statusCode === 410) await db.q(`delete from push_subscriptions where id = $1`, [s.id]);
      else console.warn('Notification failed:', e.statusCode || '', e.body || e.message);
    }
  }));
  return sent;
}

const LABEL = { instagram: 'Instagram', facebook: 'Facebook', youtube: 'YouTube', gmail: 'Gmail', telegram: 'Telegram' };

// Called after new messages are sorted. "important" = brand deals, collabs and urgent ones.
async function notifyNewMessages(userId, items) {
  if (!items.length) return;
  const u = await db.one(`select settings from users where id = $1`, [userId]);
  const mode = (u && u.settings && u.settings.notify) || 'important';
  if (mode === 'off') return;
  const picked = items.filter((c) => c.needs_reply && c.category !== 'spam' && (mode === 'all' || c.urgent || c.category === 'brand_deal' || c.category === 'collab'));
  for (const c of picked.slice(0, 5)) {
    const who = c.participant_name || 'Someone';
    const title = c.category === 'brand_deal' ? `Brand deal from ${who}` : c.category === 'collab' ? `Collab request from ${who}` : c.urgent ? `${who} needs a reply` : `${who} on ${LABEL[c.platform] || c.platform}`;
    await notifyUser(userId, {
      title,
      body: (c.reason ? c.reason + ': ' : '') + String(c.preview || '').slice(0, 120),
      url: `/inbox/${c.id}`,
      tag: c.id,
    });
  }
  if (picked.length > 5) {
    await notifyUser(userId, { title: `${picked.length - 5} more messages need you`, body: 'Open One Inbox to see them all.', url: '/inbox', tag: 'more' });
  }
}

module.exports = { publicKey, subscribe, unsubscribe, notifyUser, notifyNewMessages };
