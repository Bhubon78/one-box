// Saves what a connector found into the database, without duplicates.
const db = require('./db');

async function saveConversations(conn, conversations) {
  let newInbound = 0;
  for (const c of conversations || []) {
    const conv = await db.one(
      `insert into conversations (user_id, connection_id, platform, kind, external_id, title, participant_name, participant_id, meta)
       values ($1,$2,$3,$4,$5,$6,$7,$8,$9)
       on conflict (connection_id, external_id) do update set
         title = coalesce(nullif(excluded.title, ''), conversations.title),
         participant_name = coalesce(nullif(excluded.participant_name, ''), conversations.participant_name),
         participant_id = coalesce(nullif(excluded.participant_id, ''), conversations.participant_id),
         meta = conversations.meta || excluded.meta
       returning id`,
      [conn.user_id, conn.id, conn.platform, c.kind, String(c.external_id), c.title || '', c.participant_name || '', c.participant_id || '', JSON.stringify(c.meta || {})]
    );
    let inserted = 0;
    let inboundHere = 0;
    for (const m of c.messages || []) {
      if (!m.text && !(m.attachments && m.attachments.length)) continue;
      const row = await db.one(
        `insert into messages (conversation_id, user_id, external_id, direction, sender_name, text, attachments, sent_at, triaged)
         values ($1,$2,$3,$4,$5,$6,$7,$8,$9)
         on conflict (conversation_id, external_id) do nothing
         returning id`,
        [conv.id, conn.user_id, String(m.external_id), m.direction, m.sender_name || '', m.text || '', JSON.stringify(m.attachments || []), m.sent_at, m.direction !== 'in']
      );
      if (row) {
        inserted++;
        if (m.direction === 'in') inboundHere++;
      }
    }
    if (inserted) {
      await refreshConversation(conv.id, inboundHere > 0);
      newInbound += inboundHere;
    }
  }
  return { newInbound };
}

// Recompute the preview, time and "needs reply" from the newest message.
async function refreshConversation(conversationId, hasNewInbound) {
  const last = await db.one(
    `select direction, text, attachments, sent_at from messages where conversation_id = $1 order by sent_at desc, id desc limit 1`,
    [conversationId]
  );
  if (!last) return;
  const preview = last.text || (last.attachments && last.attachments.length ? '[' + last.attachments[0].type + ']' : '');
  await db.q(
    `update conversations set last_message_at = $2, last_preview = $3,
       needs_reply = ($4 = 'in'),
       unread = unread or $5,
       archived = case when $5 then false else archived end
     where id = $1`,
    [conversationId, last.sent_at, preview.slice(0, 200), last.direction, hasNewInbound]
  );
}

async function saveStats(conn, stats) {
  if (!stats) return;
  await db.q(
    `insert into stats (connection_id, day, followers, metrics) values ($1, current_date, $2, $3)
     on conflict (connection_id, day) do update set followers = excluded.followers, metrics = excluded.metrics`,
    [conn.id, stats.followers ?? null, JSON.stringify(stats.metrics || {})]
  );
}

module.exports = { saveConversations, refreshConversation, saveStats };
