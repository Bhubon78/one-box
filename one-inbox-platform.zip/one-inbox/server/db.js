const fs = require('fs');
const path = require('path');
const { Pool } = require('pg');
const { config } = require('./config');

let pool;

function getPool() {
  if (!pool) {
    const local = /localhost|127\.0\.0\.1/.test(config.databaseUrl);
    pool = new Pool({
      connectionString: config.databaseUrl,
      // Supabase requires SSL; local test databases don't use it.
      ssl: local ? false : { rejectUnauthorized: false },
      max: Number(process.env.DB_POOL_SIZE || 5),
    });
    pool.on('error', (e) => console.error('Database connection error:', e.message));
  }
  return pool;
}

const q = (text, params) => getPool().query(text, params);

async function one(text, params) {
  const r = await q(text, params);
  return r.rows[0] || null;
}

async function migrate() {
  const dir = path.join(__dirname, 'migrations');
  for (const file of fs.readdirSync(dir).filter((f) => f.endsWith('.sql')).sort()) {
    await q(fs.readFileSync(path.join(dir, file), 'utf8'));
  }
}

async function close() {
  if (pool) await pool.end();
  pool = null;
}

module.exports = { q, one, migrate, close, getPool };
