# One Inbox

One inbox for creators. Every Instagram DM and comment, Facebook Page message and comment, YouTube comment, Telegram chat and Gmail brand email arrives in one dashboard. Each one is sorted (brand deal, collab, question, fan, support, spam), urgent ones are flagged, a reply is drafted, and you answer from the same screen. The reply is sent from your real account on that platform.

```
  Instagram ─┐
  Facebook  ─┤   every 5 min      ┌──────────────┐     ┌───────────────┐
  YouTube   ─┼──────────────────▶ │  One Inbox   │ ──▶ │  Claude AI    │  sorts + drafts replies
  Gmail     ─┤                    │  server      │     └───────────────┘
  Telegram  ─┘   instantly        │  (Render)    │ ──▶  Supabase database (tokens encrypted)
                                  └──────┬───────┘
                                         │
                   Dashboard on laptop, and an iPhone app (Add to Home Screen)
                   with notifications for brand deals and urgent messages
```

**Putting it online for free:** follow [DEPLOY.md](DEPLOY.md), step by step. No coding needed.

## What each platform can do

| Platform | Read | Reply | Extra | Who can connect |
|---|---|---|---|---|
| Instagram | DMs, comments on your last 10 posts | DM text and images, reply under a comment, private reply to a commenter, emoji reactions | Followers, posts | Creator or Business accounts |
| Facebook | Messenger, comments on your last 10 Page posts | Messages and images, comment replies, private replies | Page followers | Pages you manage |
| YouTube | Comments on your videos | Reply to comments | Subscribers, views | Any channel |
| Gmail | Inbox from the last 7 days (no promotions or social tabs) | Threaded email replies | | Any Google account |
| Telegram | Every private chat (with Telegram Premium + Business), or messages forwarded to the bot | Replies as you, plus photos | | Anyone |

Platform rules the app follows: Instagram and Messenger only allow replies within 24 hours of the person's last message. Personal WhatsApp, personal Instagram, Snapchat and TikTok DMs have no API, so no app can read them.

## On iPhone

One Inbox is a Progressive Web App. In Safari, tap **Share → Add to Home Screen**. It gets its own icon, opens full-screen, works offline for the app itself, and sends notifications on iOS 16.4+.

- `web/public/manifest.webmanifest`: app name, icon and colours
- `web/public/sw.js`: service worker for fast start and notifications (it never stores your messages)
- `server/push.js`: Web Push. The signing (VAPID) keys are generated on first start and saved in the database. To use your own, set `VAPID_PUBLIC_KEY` and `VAPID_PRIVATE_KEY`.

## Run it on your computer

You need Node.js 20+ and a Postgres database (a free Supabase project works).

```bash
npm install
npm run build          # builds the dashboard
cp .env.example .env   # then fill in DATABASE_URL, ENCRYPTION_KEY, CRON_SECRET
npm start              # open http://localhost:3000
```

Telegram works on your computer too: without an https address the server asks Telegram for new messages itself. Instagram, Facebook and Google need the public https address from DEPLOY.md, because they send people back to it after login.

## Tests

```bash
npm test
```

This starts a real Postgres and a fake copy of each platform's API, shaped like their documented responses. Then it checks connecting, syncing, sorting and replying on all five platforms, as well as privacy between users, login lockout, expired tokens and account deletion.

## How it's built

| Folder | What's inside |
|---|---|
| `server/index.js` | Web server, security headers, routes |
| `server/auth.js` | Sign-up, login (bcrypt, lockout after 8 tries), sessions (HttpOnly cookies, only a hash stored) |
| `server/connectors/` | One file per platform: connect, sync, reply, react |
| `server/sync.js` | Automatic syncing every few minutes (one server at a time via a database lock) |
| `server/ai.js` | Sorting and reply drafts with Claude; keyword rules if no API key |
| `server/push.js` | iPhone/Android/desktop notifications |
| `server/routes/` | Dashboard API, Telegram webhook, scheduler endpoint, Meta data-deletion callback |
| `server/migrations/` | Database tables, created automatically on start |
| `web/` | React dashboard |
| `test/` | End-to-end tests |

### Security

- Platform access tokens are encrypted (AES-256-GCM) before they're saved.
- Passwords are hashed with bcrypt. Logins lock for 15 minutes after 8 wrong tries.
- Session cookies are HttpOnly, Secure and SameSite=Lax. Only a SHA-256 hash of each session is stored.
- Changes need a custom header the browser won't send from another site (CSRF protection). There's also a strict Content-Security-Policy and HSTS.
- Every database query is limited to the logged-in user's own rows. Tests check that one user can't read, reply to or delete another's data.
- Connecting a platform uses a one-time `state` value tied to your account, so forged callbacks are rejected.
- Messages are treated as untrusted when sent to the AI. The AI can only return a category and a draft, and those are checked before saving.

### Adding a platform

Copy `server/connectors/youtube.js`, then fill in `authUrl`, `handleCallback`, `sync` and `reply`. Register it in `server/connectors/index.js` and add its colour in `web/src/api.js`.
