import React from 'react';
import { PLATFORMS, CATEGORIES } from './api.js';

export function Logo() {
  return (
    <svg viewBox="0 0 64 64" aria-hidden="true">
      <rect width="64" height="64" rx="14" fill="#fff" fillOpacity="0.1" />
      <rect x="14" y="20" width="36" height="6" rx="3" fill="#f5e663" />
      <rect x="14" y="30" width="28" height="6" rx="3" fill="currentColor" opacity="0.7" />
      <rect x="14" y="40" width="20" height="6" rx="3" fill="currentColor" opacity="0.7" />
    </svg>
  );
}

export function Pf({ id, large }) {
  const p = PLATFORMS[id] || { short: '?', color: '#888', label: id };
  return (
    <span className={'pf' + (large ? ' lg' : '')} style={{ background: p.color }} title={p.label} aria-label={p.label}>
      {p.short}
    </span>
  );
}

export function CatTag({ category }) {
  if (!category) return null;
  return <span className={'tag ' + category}>{(CATEGORIES[category] || { one: category }).one}</span>;
}

export function Spinner({ label = 'Loading…' }) {
  return <p className="hint" role="status">{label}</p>;
}
