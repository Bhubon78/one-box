import React, { useState } from 'react';
import { isIOS, isStandalone } from './device.js';

const ShareIcon = () => (
  <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" style={{ verticalAlign: '-3px' }}>
    <path d="M12 3v12M8 7l4-4 4 4" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
    <path d="M6 11v8a1 1 0 0 0 1 1h10a1 1 0 0 0 1-1v-8" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
  </svg>
);

export function InstallSteps() {
  return (
    <ol className="steps">
      <li>Open this page in <strong>Safari</strong>.</li>
      <li>Tap the Share button <ShareIcon /> at the bottom of the screen.</li>
      <li>Scroll down and tap <strong>Add to Home Screen</strong>, then <strong>Add</strong>.</li>
      <li>Open <strong>One Inbox</strong> from your home screen. It opens full-screen, like any app.</li>
    </ol>
  );
}

// Shown on iPhone when the site is open in Safari instead of the home-screen app.
export default function InstallBanner() {
  const [hidden, setHidden] = useState(() => {
    try { return localStorage.getItem('ob_install_hidden') === '1'; } catch { return false; }
  });
  if (hidden || !isIOS() || isStandalone()) return null;
  const hide = () => {
    setHidden(true);
    try { localStorage.setItem('ob_install_hidden', '1'); } catch { /* private mode */ }
  };
  return (
    <aside className="install" aria-label="Install on iPhone">
      <div>
        <strong>Put One Inbox on your home screen</strong>
        <p>Tap <ShareIcon /> then <strong>Add to Home Screen</strong>. You'll get an app icon and notifications for brand deals.</p>
      </div>
      <button className="btn small ghost" onClick={hide} aria-label="Hide this tip">Not now</button>
    </aside>
  );
}
