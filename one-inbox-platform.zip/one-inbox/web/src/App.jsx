import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { Routes, Route, Navigate, NavLink, useNavigate } from 'react-router-dom';
import { api } from './api.js';
import { Logo } from './components.jsx';
import InstallBanner from './Install.jsx';
import Landing from './pages/Landing.jsx';
import { Login, Signup } from './pages/Auth.jsx';
import Overview from './pages/Overview.jsx';
import Inbox from './pages/Inbox.jsx';
import Connections from './pages/Connections.jsx';
import Settings from './pages/Settings.jsx';
import { Privacy, Terms, DataDeletion } from './pages/Legal.jsx';

const Ctx = createContext(null);
export const useApp = () => useContext(Ctx);

export default function App() {
  const [user, setUser] = useState(undefined); // undefined = still checking
  const [cfg, setCfg] = useState(null);
  const [waiting, setWaiting] = useState(0);

  useEffect(() => {
    api('/auth/me').then((r) => setUser(r.user)).catch(() => setUser(null));
    api('/config').then(setCfg).catch(() => setCfg({ appName: 'One Inbox', platforms: [], comingSoon: [] }));
  }, []);

  const refreshCount = useCallback(() => {
    if (user) api('/overview').then((o) => setWaiting(o.totals.needs_reply)).catch(() => {});
  }, [user]);
  useEffect(() => {
    refreshCount();
    const t = setInterval(refreshCount, 60000);
    return () => clearInterval(t);
  }, [refreshCount]);

  useEffect(() => {
    if (cfg) document.title = cfg.appName;
  }, [cfg]);

  if (user === undefined || !cfg) return <div className="auth"><p className="hint">Loading…</p></div>;

  const ctx = { user, setUser, cfg, waiting, refreshCount };
  const priv = (el) => (user ? <Shell>{el}</Shell> : <Navigate to="/login" replace />);

  return (
    <Ctx.Provider value={ctx}>
      <Routes>
        <Route path="/" element={user ? <Navigate to="/overview" replace /> : <Landing />} />
        <Route path="/login" element={user ? <Navigate to="/overview" replace /> : <Login />} />
        <Route path="/signup" element={user ? <Navigate to="/overview" replace /> : <Signup />} />
        <Route path="/overview" element={priv(<Overview />)} />
        <Route path="/inbox" element={priv(<Inbox />)} />
        <Route path="/inbox/:id" element={priv(<Inbox />)} />
        <Route path="/connections" element={priv(<Connections />)} />
        <Route path="/settings" element={priv(<Settings />)} />
        <Route path="/privacy" element={<Privacy />} />
        <Route path="/terms" element={<Terms />} />
        <Route path="/data-deletion" element={<DataDeletion />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Ctx.Provider>
  );
}

function Shell({ children }) {
  const { cfg, user, setUser, waiting } = useApp();
  const nav = useNavigate();
  const logout = async () => {
    await api('/auth/logout', { method: 'POST' }).catch(() => {});
    setUser(null);
    nav('/');
  };
  return (
    <div className="shell">
      <nav className="rail" aria-label="Main">
        <a className="brand" href="/overview"><Logo /> {cfg.appName}</a>
        <NavLink className="nav" to="/overview">Overview</NavLink>
        <NavLink className="nav" to="/inbox">
          <span>Inbox</span>
          {waiting > 0 && <span className="count" aria-label={`${waiting} waiting`}>{waiting > 99 ? '99+' : waiting}</span>}
        </NavLink>
        <NavLink className="nav" to="/connections">Accounts</NavLink>
        <NavLink className="nav" to="/settings">Settings</NavLink>
        <div className="foot">
          <div style={{ overflow: 'hidden', textOverflow: 'ellipsis' }}>{user.email}</div>
          <button onClick={logout}>Log out</button>
        </div>
      </nav>
      <main className="main"><InstallBanner />{children}</main>
    </div>
  );
}
