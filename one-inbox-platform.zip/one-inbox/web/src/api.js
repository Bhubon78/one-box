// Talks to the server. Every change sends the X-Requested-With header (the server's CSRF check).
export async function api(path, { method = 'GET', body } = {}) {
  const res = await fetch('/api' + path, {
    method,
    headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'onebox' },
    body: body !== undefined ? JSON.stringify(body) : undefined,
    credentials: 'same-origin',
  });
  let data = {};
  try {
    data = await res.json();
  } catch {
    /* empty response */
  }
  if (!res.ok) {
    const err = new Error(data.error || `Request failed (${res.status})`);
    err.status = res.status;
    throw err;
  }
  return data;
}

export const PLATFORMS = {
  instagram: { label: 'Instagram', short: 'IG', color: '#c0306a' },
  facebook: { label: 'Facebook', short: 'FB', color: '#2d5bd8' },
  youtube: { label: 'YouTube', short: 'YT', color: '#d02828' },
  gmail: { label: 'Gmail', short: 'GM', color: '#b8640a' },
  telegram: { label: 'Telegram', short: 'TG', color: '#1f8fc4' },
};

export const CATEGORIES = {
  brand_deal: { label: 'Brand deals', one: 'Brand deal' },
  collab: { label: 'Collabs', one: 'Collab' },
  question: { label: 'Questions', one: 'Question' },
  support: { label: 'Support', one: 'Support' },
  fan: { label: 'Fans', one: 'Fan' },
  other: { label: 'Other', one: 'Other' },
  spam: { label: 'Spam', one: 'Spam' },
};

export function ago(date) {
  const s = Math.max(1, Math.round((Date.now() - new Date(date)) / 1000));
  if (s < 60) return 'now';
  const m = Math.round(s / 60);
  if (m < 60) return `${m}m`;
  const h = Math.round(m / 60);
  if (h < 24) return `${h}h`;
  const d = Math.round(h / 24);
  if (d < 7) return `${d}d`;
  return new Date(date).toLocaleDateString(undefined, { day: 'numeric', month: 'short' });
}

export const fmt = (n) => (n == null ? '–' : n >= 1e6 ? (n / 1e6).toFixed(1).replace(/\.0$/, '') + 'M' : n >= 1e4 ? Math.round(n / 1e3) + 'K' : n >= 1e3 ? (n / 1e3).toFixed(1).replace(/\.0$/, '') + 'K' : String(n));
