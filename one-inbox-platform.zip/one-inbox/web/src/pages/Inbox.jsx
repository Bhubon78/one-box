import React, { useEffect, useRef, useState, useCallback } from 'react';
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { api, ago, PLATFORMS, CATEGORIES } from '../api.js';
import { Pf, CatTag, Spinner } from '../components.jsx';
import { useApp } from '../App.jsx';

const TABS = [
  ['needs_reply', 'Needs you'],
  ['urgent', 'Reply soon'],
  ['brand_deal', 'Brand deals'],
  ['unread', 'Unread'],
  ['comments', 'Comments'],
  ['all', 'All'],
  ['archived', 'Archived'],
];
const KIND = { dm: 'Message', comment: 'Comment', email: 'Email' };
const REACTIONS = ['❤️', '😂', '😮', '🔥', '👍', '🙏'];

export default function Inbox() {
  const { id } = useParams();
  const [sp, setSp] = useSearchParams();
  const filter = sp.get('filter') || 'needs_reply';
  const platform = sp.get('platform') || '';
  const category = sp.get('category') || '';
  const [q, setQ] = useState('');
  const [list, setList] = useState(null);
  const [err, setErr] = useState('');
  const { refreshCount } = useApp();

  const load = useCallback(() => {
    const p = new URLSearchParams({ filter });
    if (platform) p.set('platform', platform);
    if (category) p.set('category', category);
    if (q.trim()) p.set('q', q.trim());
    return api('/conversations?' + p).then((r) => { setList(r); setErr(''); }).catch((e) => setErr(e.message));
  }, [filter, platform, category, q]);

  useEffect(() => {
    const t = setTimeout(load, q ? 250 : 0);
    return () => clearTimeout(t);
  }, [load, q]);
  useEffect(() => {
    const t = setInterval(() => { if (!document.hidden) load(); }, 30000);
    return () => clearInterval(t);
  }, [load]);

  const setParam = (k, v) => {
    const n = new URLSearchParams(sp);
    if (v) n.set(k, v); else n.delete(k);
    setSp(n, { replace: true });
  };
  const keep = sp.toString() ? '?' + sp.toString() : '';

  return (
    <div className={'inbox' + (id ? ' open' : '')}>
      <section className="list-pane" aria-label="Conversations">
        <div className="list-head">
          <h1>Inbox</h1>
          <div className="tabs" role="toolbar" aria-label="Show">
            {TABS.map(([k, label]) => (
              <button key={k} aria-pressed={filter === k} onClick={() => setParam('filter', k === 'needs_reply' ? '' : k)}>{label}</button>
            ))}
          </div>
          <div className="pfilter" role="toolbar" aria-label="Platform">
            <button className="all" aria-pressed={!platform} onClick={() => setParam('platform', '')}>All</button>
            {Object.keys(PLATFORMS).map((p) => (
              <button key={p} aria-pressed={platform === p} onClick={() => setParam('platform', platform === p ? '' : p)} aria-label={PLATFORMS[p].label}>
                <Pf id={p} />
              </button>
            ))}
          </div>
          {category && CATEGORIES[category] && (
            <div><button className="btn small" onClick={() => setParam('category', '')} aria-label={`Stop showing only ${CATEGORIES[category].label}`}>Only {CATEGORIES[category].label.toLowerCase()} ✕</button></div>
          )}
          <label className="sr" htmlFor="search">Search messages</label>
          <input id="search" className="input" placeholder="Search names and messages" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <div className="conv-list">
          {err && <p className="error" style={{ padding: 16 }}>{err}</p>}
          {!list && !err && <div style={{ padding: 16 }}><Spinner /></div>}
          {list && !list.length && (
            <div style={{ padding: '24px 16px' }} className="muted">
              {q ? 'No messages match your search.' : filter === 'needs_reply' ? 'Nobody is waiting on a reply.' : 'Nothing here yet.'}
              {filter !== 'all' && !q && <> <button className="btn small" style={{ marginTop: 10 }} onClick={() => setParam('filter', 'all')}>Show all messages</button></>}
            </div>
          )}
          {list && list.map((c) => (
            <Link key={c.id} to={`/inbox/${c.id}${keep}`} className={'conv' + (c.id === id ? ' active' : '') + (c.unread ? ' unread' : '')} aria-current={c.id === id ? 'true' : undefined}>
              <Pf id={c.platform} />
              <div style={{ minWidth: 0 }}>
                <div className="top">
                  <span className="name">{c.participant_name || c.title}</span>
                  <span className="hint">{ago(c.last_message_at)}</span>
                </div>
                <div className="preview">{c.last_preview}</div>
                <div className="meta">
                  <span className="kind">{KIND[c.kind]}</span>
                  {c.urgent && c.needs_reply && <span className="tag urgent">Reply soon</span>}
                  <CatTag category={c.category} />
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>
      <section className="thread-pane" aria-label="Conversation">
        {id ? <Thread key={id} id={id} back={`/inbox${keep}`} onChange={() => { load(); refreshCount(); }} /> : <div className="nothing"><div><h2>Pick a conversation</h2><p style={{ marginTop: 6 }}>The ones waiting on you are listed first.</p></div></div>}
      </section>
    </div>
  );
}

function Thread({ id, back, onChange }) {
  const nav = useNavigate();
  const [d, setD] = useState(null);
  const [err, setErr] = useState('');
  const [text, setText] = useState('');
  const [image, setImage] = useState('');
  const [showImage, setShowImage] = useState(false);
  const [mode, setMode] = useState('public');
  const [sending, setSending] = useState(false);
  const [sendErr, setSendErr] = useState('');
  const [sentNote, setSentNote] = useState('');
  const [idea, setIdea] = useState('');
  const [instr, setInstr] = useState('');
  const [thinking, setThinking] = useState(false);
  const [reactFor, setReactFor] = useState(null);
  const bodyRef = useRef(null);

  const load = useCallback(() => api('/conversations/' + id).then((r) => { setD(r); setIdea(r.conversation.ai_reply || ''); }).catch((e) => setErr(e.message)), [id]);
  useEffect(() => { load().then(onChange); }, [load]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { if (bodyRef.current) bodyRef.current.scrollTop = bodyRef.current.scrollHeight; }, [d]);

  if (err) return <div className="nothing"><div><p className="error">{err}</p><Link className="btn" to={back} style={{ marginTop: 12 }}>Back to inbox</Link></div></div>;
  if (!d) return <div className="nothing"><Spinner /></div>;

  const c = d.conversation;
  const caps = d.capabilities || {};
  const isComment = c.kind === 'comment';

  async function send(e) {
    e.preventDefault();
    setSendErr(''); setSentNote('');
    if (!text.trim() && !image.trim()) return setSendErr('Write a reply first.');
    if (image.trim() && !/^https:\/\//i.test(image.trim())) return setSendErr('The image link must start with https://');
    setSending(true);
    try {
      await api(`/conversations/${id}/reply`, { method: 'POST', body: { text: text.trim(), imageUrl: image.trim() || undefined, mode: isComment ? mode : undefined } });
      setText(''); setImage(''); setShowImage(false);
      setSentNote(`Sent on ${PLATFORMS[c.platform].label}.`);
      await load();
      onChange();
    } catch (x) {
      setSendErr(x.message);
    }
    setSending(false);
  }
  async function another() {
    setThinking(true);
    try {
      const r = await api(`/conversations/${id}/suggest`, { method: 'POST', body: { instruction: instr.trim() || undefined } });
      setIdea(r.reply); setInstr('');
    } catch (x) {
      setSendErr(x.message);
    }
    setThinking(false);
  }
  async function patch(body, after) {
    try {
      await api('/conversations/' + id, { method: 'PATCH', body });
      onChange();
      if (after) after(); else load();
    } catch (x) {
      setSendErr(x.message);
    }
  }
  async function react(m, emoji) {
    setReactFor(null);
    try {
      await api(`/conversations/${id}/react`, { method: 'POST', body: { messageId: m.id, emoji } });
      setSentNote(`Reacted ${emoji}`);
    } catch (x) {
      setSendErr(x.message);
    }
  }

  let lastDay = '';
  return (
    <>
      <div className="thread-head">
        <Link className="btn small back" to={back} aria-label="Back to inbox">Back</Link>
        <Pf id={c.platform} large />
        <div className="grow">
          <div className="title">{c.participant_name || c.title}</div>
          <div className="hint" style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{PLATFORMS[c.platform].label} {KIND[c.kind].toLowerCase()}{c.kind !== 'dm' && c.title ? ` · ${c.title}` : ''}</div>
        </div>
        {d.link && <a className="btn small open-in" href={d.link} target="_blank" rel="noreferrer noopener">Open in {PLATFORMS[c.platform].label}</a>}
        {c.archived
          ? <button className="btn small" onClick={() => patch({ archived: false })}>Move to inbox</button>
          : <button className="btn small" onClick={() => patch({ archived: true }, () => nav(back))}>Archive</button>}
      </div>

      <div className="thread-body" ref={bodyRef}>
        {d.messages.map((m) => {
          const day = new Date(m.sent_at).toLocaleDateString(undefined, { weekday: 'short', day: 'numeric', month: 'short' });
          const sep = day !== lastDay ? <div className="day-sep">{day}</div> : null;
          lastDay = day;
          return (
            <React.Fragment key={m.id}>
              {sep}
              <div className={'bubble ' + m.direction}>
                {m.direction === 'in' && <div className="by">{m.sender_name}</div>}
                {m.text}
                {(m.attachments || []).map((a, i) => a.type === 'image'
                  ? <img key={i} src={a.url} alt="Attached image" loading="lazy" referrerPolicy="no-referrer" />
                  : <div key={i}><a href={a.url} target="_blank" rel="noreferrer noopener" style={{ color: 'inherit' }}>Open {a.type}</a></div>)}
                <div className="when">{new Date(m.sent_at).toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' })}</div>
                {m.direction === 'in' && caps.react && c.kind === 'dm' && (
                  reactFor === m.id
                    ? <div className="react-row">{REACTIONS.map((e) => <button key={e} onClick={() => react(m, e)} aria-label={`React ${e}`}>{e}</button>)}</div>
                    : <button className="btn ghost small" style={{ padding: '0 4px', marginTop: 2 }} onClick={() => setReactFor(m.id)}>React</button>
                )}
              </div>
            </React.Fragment>
          );
        })}
      </div>

      <div className="assist">
        <div className="why">
          <CatTag category={c.category} />
          {c.urgent && c.needs_reply && <span className="tag urgent">Reply soon</span>}
          <span>{c.ai_reason}</span>
          <label className="sr" htmlFor="cat">Change type</label>
          <select id="cat" className="input" style={{ width: 'auto', padding: '3px 8px', fontSize: 13, marginLeft: 'auto' }} value={c.category || 'other'} onChange={(e) => patch({ category: e.target.value })}>
            {Object.entries(CATEGORIES).map(([k, v]) => <option key={k} value={k}>{v.one}</option>)}
          </select>
          {c.needs_reply && <button className="btn small" onClick={() => patch({ needs_reply: false })}>No reply needed</button>}
        </div>
        {d.canReply && d.windowOpen && idea && (
          <>
            <div className="idea">{idea}</div>
            <div className="idea-actions">
              <button className="btn small primary" onClick={() => setText(idea)}>Use this reply</button>
              <label className="sr" htmlFor="instr">How should it change?</label>
              <input id="instr" className="input" style={{ flex: 1, minWidth: 140, padding: '5px 10px', fontSize: 14 }} placeholder="e.g. shorter, ask for their budget" value={instr} onChange={(e) => setInstr(e.target.value)} />
              <button className="btn small" onClick={another} disabled={thinking}>{thinking ? 'Writing…' : 'Write another'}</button>
            </div>
          </>
        )}
      </div>

      {!d.canReply ? (
        <div className="composer"><div className="warn">
          {c.meta && c.meta.forwarded ? 'This message was forwarded to the bot, so reply to it in Telegram.' : 'To reply from here, add the bot under Telegram Settings > Telegram Business > Chatbots.'}
        </div></div>
      ) : !d.windowOpen ? (
        <div className="composer"><div className="warn">{PLATFORMS[c.platform].label} only allows replies within 24 hours of their last message. Reply in the app instead.</div></div>
      ) : (
        <form className="composer" onSubmit={send}>
          {isComment && caps.privateReply && (
            <div className="seg" role="group" aria-label="Reply type">
              <button type="button" aria-pressed={mode === 'public'} onClick={() => setMode('public')}>Reply under comment</button>
              <button type="button" aria-pressed={mode === 'private'} onClick={() => setMode('private')}>Send as DM</button>
            </div>
          )}
          <label className="sr" htmlFor="reply">Your reply</label>
          <textarea id="reply" className="input" placeholder={`Reply to ${c.participant_name || 'them'}…`} value={text} maxLength={1000}
            onChange={(e) => { setText(e.target.value); setSendErr(''); }}
            onKeyDown={(e) => { if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) send(e); }} />
          {showImage && (
            <>
              <label className="sr" htmlFor="img">Image link</label>
              <input id="img" className="input" placeholder="https://… link to an image" value={image} onChange={(e) => { setImage(e.target.value); setSendErr(''); }} />
            </>
          )}
          <div className="row">
            <button className="btn primary" disabled={sending}>{sending ? 'Sending…' : 'Send reply'}</button>
            {caps.image && !(isComment && mode === 'public') && <button type="button" className="btn small" onClick={() => setShowImage(!showImage)}>{showImage ? 'Remove image' : 'Add image'}</button>}
            <span className="hint">{text.length}/1000</span>
            {sendErr && <span className="error" role="alert">{sendErr}</span>}
            {sentNote && !sendErr && <span className="note-ok" role="status">{sentNote}</span>}
          </div>
        </form>
      )}
    </>
  );
}
