// Meta and Google require a public privacy policy, terms and data-deletion page before review.
// Read these carefully and change anything that doesn't match how you run the service.
import React from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { useApp } from '../App.jsx';

function Doc({ title, children }) {
  return (
    <div className="doc">
      <p style={{ marginBottom: 20 }}><Link to="/">Home</Link></p>
      <h1>{title}</h1>
      {children}
    </div>
  );
}

export function Privacy() {
  const { cfg } = useApp();
  const n = cfg.appName;
  return (
    <Doc title="Privacy policy">
      <p>{n} lets creators read and answer messages from their own social media accounts in one place. This page explains what we collect and why.</p>
      <h2>What we collect</h2>
      <ul>
        <li>Your account details: email address, name and a scrambled (hashed) version of your password.</li>
        <li>For each account you connect (Instagram, Facebook Page, YouTube, Gmail, Telegram): the account name and ID, and an access key from that platform. Access keys are stored encrypted.</li>
        <li>The messages, comments and emails sent to those accounts, so we can show them in your inbox, and follower counts for your charts.</li>
      </ul>
      <h2>How we use it</h2>
      <ul>
        <li>Only to show your messages to you, send the replies you write, and sort messages by type.</li>
        <li>To sort messages and suggest replies, message text may be sent to our AI provider (Anthropic) for processing. It is not used to train AI models.</li>
        <li>We never sell your data, show you ads, or share it with anyone else.</li>
      </ul>
      <h2>Google user data</h2>
      <p>{n}'s use of information received from Google APIs adheres to the Google API Services User Data Policy, including the Limited Use requirements. Gmail and YouTube data is only used to show your emails and comments to you and send your replies.</p>
      <h2>Keeping and deleting data</h2>
      <p>Disconnecting an account deletes its messages from {n}. Deleting your account in Settings deletes everything immediately. You can also remove {n} from your Facebook, Instagram or Google settings, and we delete that platform's data. See <Link to="/data-deletion">how to delete your data</Link>.</p>
      <h2>Contact</h2>
      <p>Questions: {cfg.contactEmail}</p>
    </Doc>
  );
}

export function Terms() {
  const { cfg } = useApp();
  return (
    <Doc title="Terms of use">
      <p>By using {cfg.appName} you agree to these terms.</p>
      <ul>
        <li>Only connect accounts you own or are allowed to manage.</li>
        <li>You're responsible for the messages you send. Follow each platform's rules (Instagram, Facebook, YouTube, Google, Telegram). Don't use {cfg.appName} for spam.</li>
        <li>Suggested replies are written by AI and can be wrong. Read them before sending.</li>
        <li>The service is provided as is. Platforms can change or limit their APIs at any time, which may stop some features working.</li>
        <li>We may suspend accounts that break these terms.</li>
      </ul>
      <p>Contact: {cfg.contactEmail}</p>
    </Doc>
  );
}

export function DataDeletion() {
  const { cfg } = useApp();
  const [sp] = useSearchParams();
  const code = sp.get('code');
  return (
    <Doc title="Delete your data">
      {code && <div className="banner ok" style={{ marginTop: 12 }}>Your deletion request was received and processed. Confirmation code: <strong>{code}</strong></div>}
      <p>You can delete your data from {cfg.appName} at any time:</p>
      <ul>
        <li><strong>Everything:</strong> log in, open Settings and choose Delete account. Everything is deleted straight away.</li>
        <li><strong>One account:</strong> open Accounts and choose Disconnect. Its messages are deleted.</li>
        <li><strong>From Facebook or Instagram:</strong> remove {cfg.appName} under Settings → Apps and websites. We're told automatically and delete that data.</li>
        <li><strong>By email:</strong> write to {cfg.contactEmail} from your account's email address.</li>
      </ul>
    </Doc>
  );
}
