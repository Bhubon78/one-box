import React, { useEffect, useState, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import { api, ago, fmt, PLATFORMS } from '../api.js';
import { Pf, Spinner } from '../components.jsx';
import { useApp } from '../App.jsx';

export default function Connections() {
  const { cfg, refreshCount } = useApp();
  const [sp, setSp] = useSearchParams();
  const [rows, setRows] = useState(null);
  const [busy, setBusy] = useState('');
  const [msg, setMsg] = useState({});
  const [tgLink, setTgLink] = useState('');
  const [confirmId, setConfirmId] = useState('');

  const load = useCallback(() => api('/connections').then(setRows).catch((e) => setMsg({ bad: e.message })), []);
  useEffect(() => { load(); }, [load]);

  // Coming back from Instagram / Facebook / Google
  useEffect(() => {
    const ok = sp.get('connected');
    const bad = sp.get('error');
    if (ok) setMsg({ ok: `${PLATFORMS[ok] ? PLATFORMS[ok].label : 'Account'} connected. Your messages will appear in a minute.` });
    if (bad) setMsg({ bad });
    if (ok || bad) {
      setSp({}, { replace: true });
      const t = setTimeout(load, 4000);
      return () => clearTimeout(t);
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  async function sync(id) {
    setBusy(id); setMsg({});
    try {
      const r = await api(`/connections/${id}/sync`, { method: 'POST' });
      setMsg({ ok: r.newMessages ? `Synced. ${r.newMessages} new message${r.newMessages > 1 ? 's' : ''}.` : 'Synced. Nothing new.' });
      refreshCount();
    } catch (e) {
      setMsg({ bad: e.message });
    }
    setBusy('');
    load();
  }
  async function remove(id) {
    setBusy(id);
    try {
      await api(`/connections/${id}`, { method: 'DELETE' });
      setMsg({ ok: 'Disconnected. Its messages were removed from your inbox.' });
      setConfirmId('');
      refreshCount();
    } catch (e) {
      setMsg({ bad: e.message });
    }
    setBusy('');
    load();
  }
  async function telegram() {
    setBusy('telegram');
    try {
      const r = await api('/connect/telegram', { method: 'POST' });
      setTgLink(r.link);
    } catch (e) {
      setMsg({ bad: e.message });
    }
    setBusy('');
  }

  if (!rows) return <div className="page"><Spinner /></div>;

  return (
    <div className="page">
      <h1 style={{ marginBottom: 6 }}>Accounts</h1>
      <p className="muted" style={{ marginBottom: 24 }}>Connect the accounts you want in your inbox. New messages are fetched every few minutes.</p>
      {msg.ok && <div className="banner ok" role="status">{msg.ok}</div>}
      {msg.bad && <div className="banner bad" role="alert">{msg.bad}</div>}

      <div className="plist">
        {cfg.platforms.map((p) => {
          const mine = rows.filter((r) => r.platform === p.id);
          return (
            <div className="prow" key={p.id}>
              <Pf id={p.id} large />
              <div>
                <div className="name">{p.name}</div>
                <div className="hint">{p.needs}</div>
              </div>
              <div>
                {!p.enabled ? <span className="hint">Not set up on this server</span>
                  : p.id === 'telegram'
                    ? <button className="btn" onClick={telegram} disabled={busy === 'telegram'}>{mine.length ? 'Link another' : 'Connect'}</button>
                    : <a className="btn" href={`/api/connect/${p.id}`}>{mine.length ? 'Add another' : 'Connect'}</a>}
              </div>
              {p.id === 'telegram' && tgLink && (
                <div className="accounts">
                  <div className="account">
                    <div className="grow">
                      <strong>Open this link on the phone with your Telegram</strong>
                      <div className="hint">Then tap Start. The link works once and expires in 30 minutes.</div>
                    </div>
                    <a className="btn primary" href={tgLink} target="_blank" rel="noreferrer noopener">Open Telegram</a>
                    <button className="btn small" onClick={load}>I've tapped Start</button>
                  </div>
                </div>
              )}
              {mine.length > 0 && (
                <div className="accounts">
                  {mine.map((a) => (
                    <div className="account" key={a.id}>
                      {a.avatar_url ? <img className="avatar" src={a.avatar_url} alt="" referrerPolicy="no-referrer" onError={(e) => { e.currentTarget.style.display = 'none'; }} /> : null}
                      <div className="grow">
                        <strong>{a.account_name}</strong>{a.followers != null && <span className="hint"> · {fmt(Number(a.followers))} {a.platform === 'youtube' ? 'subscribers' : 'followers'}</span>}
                        <div className={a.status === 'ok' ? 'status-ok' : 'status-bad'}>
                          {a.status === 'ok'
                            ? (a.platform === 'telegram' ? (a.business ? 'All chats connected through Telegram Business' : 'Linked. Forward messages to the bot, or add it in Telegram Business to get every chat') : a.last_sync_at ? `Up to date, checked ${ago(a.last_sync_at) === 'now' ? 'just now' : ago(a.last_sync_at) + ' ago'}` : 'Fetching your messages…')
                            : a.status === 'reconnect' ? 'Access expired. Connect again to keep syncing.' : `Couldn't sync: ${a.last_error}`}
                        </div>
                      </div>
                      {a.status === 'reconnect' && p.enabled && p.id !== 'telegram' && <a className="btn small primary" href={`/api/connect/${p.id}`}>Connect again</a>}
                      {a.platform !== 'telegram' && <button className="btn small" onClick={() => sync(a.id)} disabled={busy === a.id}>{busy === a.id ? 'Syncing…' : 'Sync now'}</button>}
                      {confirmId === a.id
                        ? <><button className="btn small danger" onClick={() => remove(a.id)} disabled={busy === a.id}>Yes, disconnect</button><button className="btn small" onClick={() => setConfirmId('')}>Cancel</button></>
                        : <button className="btn small ghost" onClick={() => setConfirmId(a.id)}>Disconnect</button>}
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}
        {cfg.comingSoon.map((p) => (
          <div className="prow soon" key={p.id}>
            <span className="pf lg" style={{ background: '#9a90a4' }}>{p.name.slice(0, 2).toUpperCase()}</span>
            <div><div className="name">{p.name}</div><div className="hint">{p.reason}</div></div>
            <span className="hint">Coming later</span>
          </div>
        ))}
      </div>
      <p className="hint" style={{ marginTop: 20 }}>Personal WhatsApp, personal Instagram and Snapchat don't let any app read messages, so they can't be added.</p>
    </div>
  );
}
