import React from 'react';
import { Link } from 'react-router-dom';
import { useApp } from '../App.jsx';
import { Pf } from '../components.jsx';

const PILE = [
  { pf: 'instagram', who: '@glowskin.co', tag: 'Brand deal', urgent: true, msg: 'Paid partnership for our serum launch: £800 for one reel. Can you confirm by Friday?' },
  { pf: 'youtube', who: 'Leo M.', tag: 'Question', msg: 'Can you review the new camera next? Your last review helped me so much.' },
  { pf: 'gmail', who: 'Northwind Athletics', tag: 'Brand deal', urgent: true, msg: 'Spring campaign proposal attached. We need an answer tomorrow.' },
  { pf: 'instagram', who: '@crypto_bot77', tag: 'Spam', msg: 'Win free bitcoin, check my page!' },
];

export default function Landing() {
  const { cfg } = useApp();
  return (
    <div className="landing">
      <header>
        <span className="brand">{cfg.appName}</span>
        <Link className="btn ghost" to="/login">Log in</Link>
      </header>
      <section className="hero">
        <div>
          <h1>Every DM, comment and brand email in one place, sorted before you open it.</h1>
          <p className="lede">Connect Instagram, Facebook, YouTube, Telegram and Gmail. See who's waiting, spot paid offers first, and reply to all of them from one screen.</p>
          <Link className="btn primary" to="/signup" style={{ padding: '12px 22px', fontSize: 16 }}>Create a free account</Link>
        </div>
        <div className="pile" aria-label="Example of a sorted inbox">
          {PILE.map((e) => (
            <div className="env" key={e.who}>
              <Pf id={e.pf} />
              <div>
                <div className="who">
                  {e.who}
                  <span className={'tag ' + (e.tag === 'Brand deal' ? 'brand_deal' : e.tag === 'Spam' ? 'spam' : '')}>{e.tag}</span>
                  {e.urgent && <span className="tag urgent">Reply soon</span>}
                </div>
                <p className="msg">{e.msg}</p>
              </div>
            </div>
          ))}
        </div>
      </section>
      <section className="facts">
        <div><h3>Reply where they wrote</h3><p>Answer a DM, a comment or an email from here. It's sent from your own account on that platform.</p></div>
        <div><h3>Brand deals float up</h3><p>Every message is sorted into brand deals, collabs, questions, fans and spam, with a reply already drafted.</p></div>
        <div><h3>Your accounts stay yours</h3><p>We connect through each platform's official login. You can disconnect or delete everything at any time.</p></div>
      </section>
      <footer className="legal">
        <Link to="/privacy">Privacy</Link>
        <Link to="/terms">Terms</Link>
        <Link to="/data-deletion">Delete your data</Link>
      </footer>
    </div>
  );
}
