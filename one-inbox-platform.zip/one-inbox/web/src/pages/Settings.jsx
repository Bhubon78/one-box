import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../api.js';
import { Spinner } from '../components.jsx';
import { useApp } from '../App.jsx';
import Notifications from '../Notifications.jsx';

export default function Settings() {
  const { cfg, setUser } = useApp();
  const nav = useNavigate();
  const [s, setS] = useState(null);
  const [saved, setSaved] = useState('');
  const [err, setErr] = useState('');
  const [delPw, setDelPw] = useState('');
  const [delErr, setDelErr] = useState('');
  const [showDelete, setShowDelete] = useState(false);

  useEffect(() => { api('/settings').then(setS).catch((e) => setErr(e.message)); }, []);
  if (!s) return <div className="page">{err ? <p className="error">{err}</p> : <Spinner />}</div>;

  async function save(e) {
    e.preventDefault();
    setSaved(''); setErr('');
    try {
      await api('/settings', { method: 'PUT', body: { name: s.name, about: s.about, notify: s.notify } });
      setSaved('Saved.');
    } catch (x) {
      setErr(x.message);
    }
  }
  async function del(e) {
    e.preventDefault();
    if (!delPw) return setDelErr('Enter your password to confirm.');
    try {
      await api('/auth/delete-account', { method: 'POST', body: { password: delPw } });
      setUser(null);
      nav('/');
    } catch (x) {
      setDelErr(x.message);
    }
  }

  return (
    <div className="page" style={{ maxWidth: 680 }}>
      <h1 style={{ marginBottom: 24 }}>Settings</h1>
      <form onSubmit={save}>
        <div className="field">
          <label htmlFor="n">Your name</label>
          <input id="n" className="input" value={s.name} onChange={(e) => setS({ ...s, name: e.target.value })} />
        </div>
        <div className="field">
          <label htmlFor="e">Email</label>
          <input id="e" className="input" value={s.email} disabled />
        </div>
        <div className="field">
          <label htmlFor="a">About you, for suggested replies</label>
          <textarea id="a" className="input" rows={4} maxLength={1000} value={s.about}
            placeholder="e.g. Fitness creator in London. Reels start at £400, stories £150. I only work with vegan brands. Friendly, short replies with an emoji."
            onChange={(e) => setS({ ...s, about: e.target.value })} />
          <span className="hint">{cfg.ai ? 'The AI uses this to write replies that sound like you and know your rates.' : 'AI replies are off on this server, so simple templates are used instead.'}</span>
        </div>
        <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
          <button className="btn primary">Save changes</button>
          {saved && <span className="note-ok" role="status">{saved}</span>}
          {err && <span className="error" role="alert">{err}</span>}
        </div>
      </form>

      <Notifications settings={s} setSettings={setS} />

      <h2 style={{ margin: '44px 0 8px' }}>Delete account</h2>
      <p className="muted" style={{ marginBottom: 14 }}>Deletes your account, every connected account and every saved message. This can't be undone.</p>
      {!showDelete ? (
        <button className="btn danger" onClick={() => setShowDelete(true)}>Delete my account</button>
      ) : (
        <form onSubmit={del}>
          <div className="field">
            <label htmlFor="dp">Your password</label>
            <input id="dp" type="password" className="input" autoComplete="current-password" value={delPw} onChange={(e) => { setDelPw(e.target.value); setDelErr(''); }} />
          </div>
          {delErr && <p className="error" role="alert" style={{ marginBottom: 10 }}>{delErr}</p>}
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="btn danger">Delete everything</button>
            <button type="button" className="btn" onClick={() => setShowDelete(false)}>Cancel</button>
          </div>
        </form>
      )}
    </div>
  );
}
