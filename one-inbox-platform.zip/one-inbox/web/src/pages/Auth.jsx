import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api } from '../api.js';
import { useApp } from '../App.jsx';

function Form({ mode }) {
  const { setUser, cfg } = useApp();
  const nav = useNavigate();
  const [f, setF] = useState({ name: '', email: '', password: '' });
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const signup = mode === 'signup';
  const set = (k) => (e) => { setF({ ...f, [k]: e.target.value }); setErr(''); };

  async function submit(e) {
    e.preventDefault();
    if (!f.email || !f.password) return setErr('Enter your email and password.');
    if (signup && f.password.length < 10) return setErr('Use a password with at least 10 characters.');
    setBusy(true);
    try {
      const r = await api(signup ? '/auth/signup' : '/auth/login', { method: 'POST', body: f });
      setUser(r.user);
      nav(signup ? '/connections' : '/overview');
    } catch (x) {
      setErr(x.message);
      setBusy(false);
    }
  }

  return (
    <div className="auth">
      <form onSubmit={submit} noValidate>
        <h1>{signup ? 'Create your account' : 'Log in'}</h1>
        <p className="muted" style={{ marginBottom: 22 }}>{signup ? `Free. Connect your accounts right after.` : `Welcome back to ${cfg.appName}.`}</p>
        {signup && (
          <div className="field">
            <label htmlFor="name">Your name</label>
            <input id="name" className="input" autoComplete="name" value={f.name} onChange={set('name')} />
          </div>
        )}
        <div className="field">
          <label htmlFor="email">Email</label>
          <input id="email" className="input" type="email" autoComplete="email" value={f.email} onChange={set('email')} />
        </div>
        <div className="field">
          <label htmlFor="password">Password</label>
          <input id="password" className="input" type="password" autoComplete={signup ? 'new-password' : 'current-password'} value={f.password} onChange={set('password')} />
          {signup && <span className="hint">At least 10 characters.</span>}
        </div>
        {err && <p className="error" role="alert" style={{ marginBottom: 12 }}>{err}</p>}
        <button className="btn primary" style={{ width: '100%' }} disabled={busy}>{busy ? 'One moment…' : signup ? 'Create account' : 'Log in'}</button>
        <p className="switch">
          {signup ? <>Already have an account? <Link to="/login">Log in</Link></> : <>New here? <Link to="/signup">Create an account</Link></>}
        </p>
      </form>
    </div>
  );
}

export const Login = () => <Form mode="login" />;
export const Signup = () => <Form mode="signup" />;
