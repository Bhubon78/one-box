import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api, ago, fmt, CATEGORIES, PLATFORMS } from '../api.js';
import { Pf, CatTag, Spinner } from '../components.jsx';
import { useApp } from '../App.jsx';

const RACK = ['brand_deal', 'collab', 'question', 'support', 'fan', 'spam'];

function Headline({ t }) {
  if (!t.needs_reply) return <h1 className="headline">Nobody is waiting on you. <span className="quiet">Inbox clear.</span></h1>;
  const people = t.needs_reply === 1 ? '1 person is' : `${t.needs_reply} people are`;
  return (
    <h1 className="headline">
      <mark>{people} waiting</mark> on you.{' '}
      {t.brand_deals > 0 ? <>{t.brand_deals === 1 ? '1 is a brand.' : `${t.brand_deals} are brands.`}</> : <span className="quiet">No brand offers right now.</span>}
    </h1>
  );
}

export default function Overview() {
  const { user } = useApp();
  const [o, setO] = useState(null);
  const [err, setErr] = useState('');
  useEffect(() => {
    api('/overview').then(setO).catch((e) => setErr(e.message));
  }, []);

  if (err) return <div className="page"><p className="error">{err}</p></div>;
  if (!o) return <div className="page"><Spinner /></div>;

  const today = new Date().toLocaleDateString(undefined, { weekday: 'long', day: 'numeric', month: 'long' });
  const first = (user.name || '').split(' ')[0];

  if (!o.accounts.length) {
    return (
      <div className="page">
        <p className="date">{today}</p>
        <h1 className="headline">{first ? `Hi ${first}. ` : ''}Connect an account to start sorting.</h1>
        <div className="empty-cta">
          <p>Your inbox fills up as soon as you connect Instagram, Facebook, YouTube, Telegram or Gmail.</p>
          <Link className="btn primary" to="/connections">Connect an account</Link>
        </div>
      </div>
    );
  }

  const cats = Object.fromEntries(o.byCategory.map((c) => [c.category, c]));
  const days = [];
  for (let i = 13; i >= 0; i--) {
    const d = new Date(Date.now() - i * 864e5);
    const key = d.toISOString().slice(0, 10);
    days.push({ key, n: (o.activity.find((a) => a.day === key) || {}).n || 0, label: d.toLocaleDateString(undefined, { day: 'numeric', month: 'short' }) });
  }
  const maxDay = Math.max(1, ...days.map((d) => d.n));
  const total14 = days.reduce((s, d) => s + d.n, 0);

  return (
    <div className="page">
      <p className="date">{today}</p>
      <Headline t={o.totals} />

      <div className="rack" aria-label="Messages by type">
        {RACK.map((k) => {
          const c = cats[k] || { n: 0, names: [] };
          return (
            <Link key={k} className={'slot' + (k === 'brand_deal' ? ' deal' : '') + (c.n ? '' : ' zero')} to={`/inbox?filter=all&category=${k}`}>
              <div className="n">{c.n}</div>
              <div className="k">{CATEGORIES[k].label}</div>
              <div className="who">{(c.names || []).filter(Boolean).join(', ') || 'None yet'}</div>
            </Link>
          );
        })}
      </div>

      <div className="section-head">
        <h2>Reply to these first</h2>
        <Link to="/inbox?filter=needs_reply" className="hint">See all {o.totals.needs_reply}</Link>
      </div>
      {o.top.length ? (
        <div className="waiting">
          {o.top.map((c) => (
            <Link key={c.id} className="wrow" to={`/inbox/${c.id}`}>
              <Pf id={c.platform} />
              <div style={{ minWidth: 0 }}>
                <div className="t">{c.participant_name || c.title}</div>
                <div className="p">{c.ai_reason || c.last_preview}</div>
              </div>
              <div className="side">
                <span className="hint">{ago(c.last_message_at)}</span>
                <span style={{ display: 'flex', gap: 4 }}>{c.urgent && <span className="tag urgent">Reply soon</span>}<CatTag category={c.category} /></span>
              </div>
            </Link>
          ))}
        </div>
      ) : (
        <p className="muted">Everything has a reply. Nice work.</p>
      )}

      <div className="two">
        <section>
          <div className="section-head"><h2>Your audience</h2><Link to="/connections" className="hint">Manage accounts</Link></div>
          {o.accounts.map((a) => {
            const pts = (a.trend || []).filter((p) => p.followers != null);
            const last = pts.length ? Number(pts[pts.length - 1].followers) : null;
            const firstN = pts.length ? Number(pts[0].followers) : null;
            const delta = last != null && firstN != null && pts.length > 1 ? last - firstN : null;
            const label = a.platform === 'youtube' ? 'subscribers' : a.platform === 'gmail' || a.platform === 'telegram' ? '' : 'followers';
            return (
              <div className="acct" key={a.id}>
                <Pf id={a.platform} large />
                <div style={{ minWidth: 0 }}>
                  <div style={{ fontWeight: 600 }}>{a.account_name}</div>
                  <div className="hint">{PLATFORMS[a.platform].label}{a.status !== 'ok' && <span className="status-bad"> · needs attention</span>}</div>
                </div>
                <div>
                  {label ? <><div className="big">{fmt(last)}</div><div className={'delta' + (delta > 0 ? ' up' : '')}>{delta ? `${delta > 0 ? '+' : ''}${fmt(delta)} in ${pts.length} days` : label}</div></> : <div className="hint">messages only</div>}
                </div>
              </div>
            );
          })}
        </section>
        <section>
          <div className="section-head"><h2>Messages received</h2><span className="hint">{total14} in 14 days</span></div>
          <div className="bars" role="img" aria-label={`Messages per day over the last 14 days, ${total14} in total`}>
            {days.map((d, i) => <div key={d.key} className={i === days.length - 1 ? 'today' : ''} style={{ height: `${(d.n / maxDay) * 100}%` }} title={`${d.label}: ${d.n}`} />)}
          </div>
          <div className="bars-x"><span>{days[0].label}</span><span>Today</span></div>
        </section>
      </div>
    </div>
  );
}
