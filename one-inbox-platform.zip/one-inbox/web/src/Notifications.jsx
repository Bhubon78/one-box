import React, { useEffect, useState } from 'react';
import { api } from './api.js';
import { isIOS, isStandalone, pushSupported, keyToBytes } from './device.js';
import { InstallSteps } from './Install.jsx';

const MODES = [
  ['important', 'Important only', 'Brand deals, collab requests and messages that need a reply soon'],
  ['all', 'Every new message', 'Everything except spam'],
  ['off', 'Off', 'No notifications'],
];

export default function Notifications({ settings, setSettings }) {
  const [state, setState] = useState('checking'); // checking | on | off | blocked | unsupported | needs-install
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState({});

  useEffect(() => {
    (async () => {
      if (isIOS() && !isStandalone()) return setState('needs-install');
      if (!pushSupported()) return setState('unsupported');
      if (Notification.permission === 'denied') return setState('blocked');
      const reg = await navigator.serviceWorker.getRegistration();
      const sub = reg && (await reg.pushManager.getSubscription());
      setState(sub ? 'on' : 'off');
    })().catch(() => setState('unsupported'));
  }, []);

  async function turnOn() {
    setBusy(true); setMsg({});
    try {
      // iPhone only allows this right after a tap, so it must be the first thing we do.
      const perm = await Notification.requestPermission();
      if (perm !== 'granted') {
        setState(perm === 'denied' ? 'blocked' : 'off');
        setBusy(false);
        return;
      }
      const reg = (await navigator.serviceWorker.getRegistration()) || (await navigator.serviceWorker.register('/sw.js'));
      await navigator.serviceWorker.ready;
      const { key } = await api('/push/key');
      const sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: keyToBytes(key) });
      await api('/push/subscribe', { method: 'POST', body: { subscription: sub.toJSON() } });
      setState('on');
      setSettings({ ...settings, devices: (settings.devices || 0) + 1 });
      await api('/push/test', { method: 'POST' }).catch(() => {});
      setMsg({ ok: 'Notifications are on for this device. A test notification is on its way.' });
    } catch (e) {
      setMsg({ bad: e.message || 'Notifications could not be turned on.' });
    }
    setBusy(false);
  }

  async function turnOff() {
    setBusy(true); setMsg({});
    try {
      const reg = await navigator.serviceWorker.getRegistration();
      const sub = reg && (await reg.pushManager.getSubscription());
      if (sub) {
        await api('/push/unsubscribe', { method: 'POST', body: { endpoint: sub.endpoint } });
        await sub.unsubscribe();
      }
      setState('off');
      setMsg({ ok: 'Notifications are off for this device.' });
    } catch (e) {
      setMsg({ bad: e.message });
    }
    setBusy(false);
  }

  async function test() {
    setMsg({});
    try {
      await api('/push/test', { method: 'POST' });
      setMsg({ ok: 'Test sent. It can take a few seconds to arrive.' });
    } catch (e) {
      setMsg({ bad: e.message });
    }
  }

  async function setMode(mode) {
    const next = { ...settings, notify: mode };
    setSettings(next);
    try {
      await api('/settings', { method: 'PUT', body: { name: next.name, about: next.about, notify: mode } });
    } catch (e) {
      setMsg({ bad: e.message });
    }
  }

  return (
    <section>
      <h2 style={{ margin: '44px 0 8px' }}>Notifications</h2>

      <div className="panel">
        {state === 'checking' && <p className="hint">Checking this device…</p>}
        {state === 'needs-install' && (
          <>
            <p><strong>On iPhone, notifications work once One Inbox is on your home screen.</strong></p>
            <InstallSteps />
            <p className="hint" style={{ marginTop: 8 }}>Then come back to Settings in the app and turn notifications on. This needs iOS 16.4 or newer.</p>
          </>
        )}
        {state === 'unsupported' && <p>This browser can't show notifications. On iPhone, update to iOS 16.4 or newer and open One Inbox from your home screen.</p>}
        {state === 'blocked' && <p>Notifications are blocked for One Inbox. On iPhone, open <strong>Settings → Notifications → One Inbox</strong> and turn on <strong>Allow Notifications</strong>, then come back here.</p>}
        {state === 'off' && (
          <>
            <p style={{ marginBottom: 12 }}>Get a notification on this device when a brand deal or urgent message arrives.</p>
            <button className="btn primary" onClick={turnOn} disabled={busy}>{busy ? 'Turning on…' : 'Turn on notifications'}</button>
          </>
        )}
        {state === 'on' && (
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center' }}>
            <span className="note-ok" style={{ marginRight: 'auto' }}>On for this device</span>
            <button className="btn small" onClick={test}>Send a test</button>
            <button className="btn small" onClick={turnOff} disabled={busy}>Turn off here</button>
          </div>
        )}
        {msg.ok && <p className="note-ok" role="status" style={{ marginTop: 10 }}>{msg.ok}</p>}
        {msg.bad && <p className="error" role="alert" style={{ marginTop: 10 }}>{msg.bad}</p>}
      </div>

      <fieldset style={{ border: 0, padding: 0, margin: 0 }}>
        <legend className="hint" style={{ marginBottom: 2 }}>What to notify you about (all your devices)</legend>
        {MODES.map(([k, label, hint]) => (
          <label className="choice" key={k}>
            <input type="radio" name="notify" value={k} checked={(settings.notify || 'important') === k} onChange={() => setMode(k)} />
            <span><strong>{label}</strong><br /><span className="hint">{hint}</span></span>
          </label>
        ))}
      </fieldset>
    </section>
  );
}
