# Putting One Inbox online (free)

This guide takes you from the zip file to a live website people can sign up to. No coding is needed: you copy and paste values between websites. Allow about an hour for the first time.

```
 Step 1 GitHub ──▶ Step 2 Supabase ──▶ Step 3 Render ──▶ Step 4 Scheduler
 (stores code)     (database)          (runs the site)   (keeps it syncing)
                                              │
              then switch on platforms, easiest first:
              Step 5 Telegram ▶ Step 6 YouTube + Gmail ▶ Step 7 Instagram + Facebook ▶ Step 8 AI
                                              │
                          Step 9: install it on your iPhone, with notifications
```

All of these are free: GitHub, Supabase, Render, cron-job.org, Telegram, Google Cloud and Meta for Developers. The only paid part is the AI (step 8), which is optional and charged per use.

Keep a note open while you work, and paste each value into it as you get it. You'll need them in step 3 and later.

---

## Step 1. Put the code on GitHub

1. Create a free account at **github.com**.
2. Click **+** (top right) → **New repository**. Name it `one-inbox`, choose **Private**, and click **Create repository**.
3. On the next page, click **uploading an existing file**.
4. Unzip `one-inbox.zip` on your Mac. Open the `one-inbox` folder, select everything inside it, and drag it all into the GitHub page.
   - Finder hides files whose names start with a dot. Press **Cmd + Shift + .** to show them so `.github` and `.gitignore` get uploaded too.
5. Click **Commit changes**.

## Step 2. Create the database (Supabase)

1. Create a free account at **supabase.com** → **New project**.
2. Name it `one-inbox`. Click **Generate a password**, then **copy the password into your note**. Pick the region closest to you (for example London) and click **Create new project**.
3. When it's ready, click **Connect** at the top of the page.
4. Choose **Session pooler** and copy the connection string. It looks like:
   `postgresql://postgres.abcd:[YOUR-PASSWORD]@aws-0-eu-west-2.pooler.supabase.com:5432/postgres`
5. Replace `[YOUR-PASSWORD]` with your password and save it in your note as **DATABASE_URL**.

> Use **Session pooler**, not "Direct connection". Render can't reach the direct one.

You don't need to create any tables. The app does that itself the first time it starts.

## Step 3. Run the site (Render)

1. Create a free account at **render.com** and sign in with GitHub.
2. Click **New +** → **Blueprint**. Pick your `one-inbox` repository.
3. Render reads the settings file and asks you for some values. For now fill in only these and leave the rest empty:
   - **DATABASE_URL**: from step 2
   - **PUBLIC_URL**: type `https://one-inbox.onrender.com` for now (you'll correct it in a moment)
   - **CONTACT_EMAIL**: your email (it's shown on the privacy page)
4. Click **Apply**. The first build takes about 5 minutes.
5. When it says **Live**, copy the address at the top of the page (for example `https://one-inbox-x7k2.onrender.com`).
6. Go to **Environment**, set **PUBLIC_URL** to that exact address (no `/` at the end) and save. Render restarts by itself.
7. Open the address. You should see the One Inbox homepage. Create your own account.

Everything below uses this address. In this guide it's written as **YOUR-URL**.

## Step 4. Keep it awake and syncing

Render's free servers go to sleep after 15 minutes without visitors, and a sleeping server can't fetch new messages. A free scheduler fixes that by calling the server every 10 minutes. It also stops Supabase pausing the database, which happens after a week with no activity.

1. In Render → **Environment**, find **CRON_SECRET**, click the eye icon and copy the value.
2. Create a free account at **cron-job.org** → **Create cronjob**.
3. URL: `YOUR-URL/api/cron?key=CRON_SECRET` (with your real address and secret).
4. Schedule: **every 10 minutes**. Save.

The first run should show status **200**.

## Step 5. Telegram (5 minutes)

1. In Telegram, open **@BotFather** and send `/newbot`. Give it a name (for example "One Inbox") and a username ending in `bot`.
2. BotFather replies with a **token**. Copy it.
3. Still in BotFather, send `/mybots` → choose your bot → **Bot Settings** → **Business Mode** → **Turn on**.
4. In Render → **Environment**, set:
   - **TELEGRAM_BOT_TOKEN**: the token
   - **TELEGRAM_BOT_USERNAME**: the username, without the @
5. Save. Then in One Inbox go to **Accounts** → Telegram → **Connect**, and tap **Start** in Telegram.

To see *all* your chats, add the bot in Telegram: **Settings → Telegram Business → Chatbots** (this needs Telegram Premium). Without Premium, you can forward any message to the bot.

## Step 6. YouTube and Gmail (Google)

1. Go to **console.cloud.google.com** → create a project called `one-inbox`.
2. Search the top bar for **YouTube Data API v3** → **Enable**. Then search for **Gmail API** → **Enable**.
3. Open **Google Auth Platform** (also called "OAuth consent screen") and click **Get started**:
   - App name: `One Inbox`. Support email: yours.
   - Audience: **External**.
   - Contact email: yours. Accept and **Create**.
4. **Branding**: add the app home page `YOUR-URL`, privacy policy `YOUR-URL/privacy` and terms `YOUR-URL/terms`.
5. **Audience** → **Test users** → add your Gmail address, and the Gmail address of anyone else who'll test (up to 100).
6. **Data access** → **Add or remove scopes** → tick:
   - `.../auth/youtube.force-ssl`
   - `.../auth/gmail.readonly`
   - `.../auth/gmail.send`
7. **Clients** → **Create client** → type **Web application**. Under **Authorized redirect URIs**, add both:
   - `YOUR-URL/api/connect/youtube/callback`
   - `YOUR-URL/api/connect/gmail/callback`
8. Copy the **Client ID** and **Client secret** into Render as **GOOGLE_CLIENT_ID** and **GOOGLE_CLIENT_SECRET**.

While the app is in "Testing", Google shows a "Google hasn't verified this app" screen. Click **Continue**. Only your test users can connect.

## Step 7. Instagram and Facebook (Meta)

Your Instagram account must be a **Creator** or **Business** account (Instagram → Settings → Account type). To connect Facebook, you need a Facebook Page.

Meta often renames these menus. If a name differs, look for the closest match.

1. Go to **developers.facebook.com** → **My Apps** → **Create app**. Name it `One Inbox`.
2. When asked what the app does, choose the Instagram use case (**Manage messaging and content on Instagram**). Also add the Messenger / Pages use case (**Engage with customers on Messenger** / **Manage everything on your Page**).

**Instagram**

3. Open **Instagram → API setup with Instagram login**. At the top you'll see an **Instagram app ID** and **Instagram app secret**. Copy them into Render as **INSTAGRAM_APP_ID** and **INSTAGRAM_APP_SECRET**.
4. On the same page, open **Set up Instagram business login** → **Business login settings**. Add the redirect URL `YOUR-URL/api/connect/instagram/callback`.
5. Go to **App roles → Roles** → **Add people** → **Instagram Tester** and add your Instagram username. Then accept the invite at instagram.com → **Settings → Apps and websites → Tester invites**.

**Facebook Page and Messenger**

6. Open **App settings → Basic**. Copy **App ID** and **App secret** into Render as **META_APP_ID** and **META_APP_SECRET**.
7. On the same page, fill in:
   - Privacy policy URL: `YOUR-URL/privacy`
   - Terms of service URL: `YOUR-URL/terms`
   - User data deletion: choose **Data deletion callback URL** → `YOUR-URL/api/meta/data-deletion`
   - App domain: your address without `https://`
8. Open **Facebook Login → Settings**. Under **Valid OAuth Redirect URIs** add `YOUR-URL/api/connect/facebook/callback`.
9. Make sure these permissions are added to your use cases: `pages_show_list`, `pages_messaging`, `pages_read_engagement`, `pages_read_user_content`, `pages_manage_engagement`, `instagram_business_basic`, `instagram_business_manage_messages`, `instagram_business_manage_comments`.

Save in Render. Then connect each account in One Inbox → **Accounts**.

## Step 8. Turn on AI sorting and replies (optional)

1. Go to **console.anthropic.com** → add a payment method → **API keys** → **Create key**.
2. In Render, set **ANTHROPIC_API_KEY** to the key. Leave **AI_MODEL** as it is (a fast, low-cost model).

Without a key, the app still works. It uses keyword rules to spot brand deals and spam, and simple template replies.

Then open **Settings** in One Inbox and fill in **About you**: your niche, rates and tone. The AI uses it to write replies that sound like you.

## Step 9. Install it on your iPhone

One Inbox installs like an app straight from the website, with no App Store needed. Everyone who signs up can do the same.

```
 Safari ──▶ Share ⬆ ──▶ Add to Home Screen ──▶ App icon ──▶ Settings ▶ Turn on notifications
```

1. On your iPhone, open **YOUR-URL** in **Safari** and log in.
2. Tap the **Share** button (the square with an arrow) → scroll down → **Add to Home Screen** → **Add**.
3. Open **One Inbox** from your home screen. It opens full-screen with its own icon, and stays logged in.
4. Go to **Settings → Notifications → Turn on notifications** and tap **Allow**. A test notification arrives within a few seconds.

From then on your phone buzzes when a brand deal, a collab request or an urgent message arrives. In Settings you can switch to "Every new message" or "Off".

- Notifications need **iOS 16.4 or newer**, and the app must be opened from the home screen. In plain Safari, iPhones don't allow notifications from websites.
- The notification keys are created automatically. There's nothing extra to set up on Render.
- Notifications show who wrote and the start of their message on your lock screen. To hide that, go to iPhone **Settings → Notifications → One Inbox → Show Previews → Never**.
- Updates reach the app automatically. After you change the code on GitHub and Render redeploys, the next time the app opens it uses the new version.

**Want it in the App Store too?** That's possible later by wrapping the same app with a tool called Capacitor, built in Xcode on your Mac. It needs an Apple Developer account ($99 a year) and Apple's review, and Apple sometimes rejects apps that are mostly a website. The home-screen version above does almost everything an App Store app would, for free.

---

## Letting other people use it

Right now it works for **you and your testers**. Before strangers can connect their accounts, each platform reviews your app:

| Platform | What's needed | Time and cost |
|---|---|---|
| Telegram | Nothing | Ready now |
| Meta (Instagram, Facebook) | **Business Verification** plus **App Review** for each permission in step 7. You record a short screen video of logging in, seeing messages and replying. | Free, usually 1 to 4 weeks |
| YouTube | Google **app verification** (the YouTube permission is "sensitive") | Free, a few days to weeks |
| Gmail | Google verification plus a yearly **security assessment (CASA)** by an approved company, because reading email is "restricted" | Paid (from roughly $500 a year) and takes weeks |

Simplest launch plan: launch with Telegram, YouTube, Instagram and Facebook. Leave Gmail for you and up to 100 testers until you're ready for the security assessment.

## What it costs

| Item | Free plan limits | When you'd pay |
|---|---|---|
| Render | One always-on server with the scheduler (750 free hours a month). It can be slow to wake if the scheduler stops. | $7/month Starter: never sleeps, faster |
| Supabase | 500 MB database, roughly tens of thousands of messages | $25/month Pro: more space, daily backups |
| Claude AI | Pay per use. A small, fast model sorting a few hundred messages a day costs pennies. | Always paid, but optional |
| Gmail security assessment | Not needed for 100 testers | Only to open Gmail to the public |

## If something goes wrong

| What you see | What to do |
|---|---|
| Render build fails | Open **Logs** in Render and read the last red lines. Usually a file wasn't uploaded in step 1, often the hidden `.github` or `.gitignore`. |
| "Please fix your settings: DATABASE_URL…" in the logs | A required value is empty or wrong in Render → Environment. |
| "connection refused" or "ENETUNREACH" to the database | You used the Direct connection. Use the **Session pooler** string (step 2). |
| A platform shows "Not set up on this server" | Its keys are missing in Render → Environment. |
| "redirect_uri mismatch" / "URL blocked" when connecting | The redirect URL in Google or Meta must match `YOUR-URL/api/connect/<platform>/callback` exactly, with https and no extra `/`. |
| "Access blocked" from Google | Add that Gmail address as a test user (step 6.5). |
| Instagram shows "Insufficient developer role" | Add the account as an Instagram Tester and accept the invite (step 7.5). |
| Account says "Access expired" | Click **Connect again** on the Accounts page. |
| Telegram bot doesn't answer | Check the token and username in Render, then restart the service. Make sure Business Mode is on in BotFather. |
| Nothing new for a long time | Check that cron-job.org shows status 200 every 10 minutes. |
| No "Add to Home Screen" option | Use Safari (not Chrome or the Instagram in-app browser), and scroll down in the Share menu. |
| No notifications on iPhone | Open the app from the home-screen icon, not Safari. Check iOS is 16.4+. In iPhone Settings → Notifications → One Inbox, make sure they're allowed. Then try **Send a test**. |

Never change **ENCRYPTION_KEY** after people have connected accounts. If you do, saved connections stop working and everyone has to connect again.
