// A fake Instagram / Facebook / Google / Telegram API, shaped like the real documented responses.
// Records every request so tests can check exactly what was sent.
const http = require('http');

function startMock(port) {
  const calls = [];
  const now = Math.floor(Date.now() / 1000);
  const t = (minsAgo) => new Date(Date.now() - minsAgo * 60e3).toISOString();

  const routes = [
    // ---------- Instagram ----------
    ['POST', /^\/oauth\/access_token$/, () => ({ access_token: 'IG_SHORT', user_id: 17841400000000001 })],
    ['GET', /^\/access_token$/, (q) => (q.grant_type === 'ig_exchange_token' && q.access_token === 'IG_SHORT' ? { access_token: 'IG_LONG', token_type: 'bearer', expires_in: 5183944 } : { __status: 400, error: { message: 'bad token' } })],
    ['GET', /^\/refresh_access_token$/, () => ({ access_token: 'IG_LONG2', expires_in: 5183944 })],
    ['GET', /^\/v25\.0\/me$/, (q) => q.access_token === 'EXPIRED'
      ? { __status: 400, error: { message: 'Error validating access token', code: 190 } }
      : { id: '9000000001', user_id: '17841400000000001', username: 'maya.creates', name: 'Maya', profile_picture_url: 'https://cdn.example/maya.jpg', followers_count: 48210, follows_count: 310, media_count: 412 }],
    ['GET', /^\/v25\.0\/me\/conversations$/, () => ({
      data: [{ id: 'aWdfconv1', updated_time: t(5), participants: { data: [{ username: 'maya.creates', id: '17841400000000001' }, { username: 'glowskin.co', id: 'IGSID_BRAND' }] } }],
    })],
    ['GET', /^\/v25\.0\/aWdfconv1$/, () => ({
      messages: { data: [
        { id: 'm_ig_2', created_time: t(5), from: { username: 'glowskin.co', id: 'IGSID_BRAND' }, to: { data: [{ id: '17841400000000001' }] }, message: 'Hi Maya! We would love a paid partnership for our new serum launch. Budget is £800 for 1 reel. Can you confirm by Friday?' },
        { id: 'm_ig_1', created_time: t(60), from: { username: 'maya.creates', id: '17841400000000001' }, message: 'Hey! Thanks for following 💕' },
      ] },
    })],
    ['GET', /^\/v25\.0\/me\/media$/, () => ({ data: [{ id: 'media1', caption: 'Morning routine 🌞 #skincare', timestamp: t(300), permalink: 'https://www.instagram.com/p/abc/', comments_count: 2 }] })],
    ['GET', /^\/v25\.0\/media1\/comments$/, () => ({ data: [
      { id: 'c_ig_1', text: 'Where is your top from?? 😍', timestamp: t(30), username: 'fan_amy', from: { id: 'IGSID_AMY', username: 'fan_amy' } },
      { id: 'c_ig_2', text: 'Win free bitcoin, check my page!', timestamp: t(20), username: 'crypto_bot77', from: { id: 'IGSID_SPAM' } },
    ] })],
    ['POST', /^\/v25\.0\/17841400000000001\/messages$/, (q, body) => ({ recipient_id: body.recipient && body.recipient.id, message_id: 'm_ig_sent_' + calls.length })],
    ['POST', /^\/v25\.0\/c_ig_1\/replies$/, () => ({ id: 'c_ig_reply_1' })],

    // ---------- Facebook ----------
    ['GET', /^\/v25\.0\/oauth\/access_token$/, (q) => (q.grant_type === 'fb_exchange_token' ? { access_token: 'FB_USER_LONG' } : { access_token: 'FB_USER_SHORT' })],
    ['GET', /^\/v25\.0\/me\/accounts$/, () => ({ data: [{ id: 'PAGE1', name: 'Maya Creates', access_token: 'PAGE_TOKEN', picture: { data: { url: 'https://cdn.example/page.jpg' } } }] })],
    ['GET', /^\/v25\.0\/PAGE1$/, () => ({ followers_count: 12034, fan_count: 11800 })],
    ['GET', /^\/v25\.0\/PAGE1\/conversations$/, () => ({ data: [{
      id: 't_fb1', updated_time: t(10),
      participants: { data: [{ id: 'PAGE1', name: 'Maya Creates' }, { id: 'PSID_JO', name: 'Jo Patel' }] },
      messages: { data: [{ id: 'm_fb_1', created_time: t(10), from: { id: 'PSID_JO', name: 'Jo Patel' }, message: 'Do you do 1:1 coaching?' }] },
    }] })],
    ['GET', /^\/v25\.0\/PAGE1\/posts$/, () => ({ data: [{ id: 'PAGE1_post1', message: 'New video out now!', permalink_url: 'https://facebook.com/post1',
      comments: { data: [{ id: 'c_fb_1', message: 'Loved this one', created_time: t(40), from: { id: 'U1', name: 'Sam Lee' }, comments: { data: [] } }] } }] })],
    ['POST', /^\/v25\.0\/PAGE1\/messages$/, () => ({ recipient_id: 'PSID_JO', message_id: 'm_fb_sent' })],
    ['POST', /^\/v25\.0\/c_fb_1\/comments$/, () => ({ id: 'c_fb_reply' })],

    // ---------- Google (YouTube + Gmail) ----------
    ['POST', /^\/token$/, (q, body, form) => (form.grant_type === 'refresh_token' ? { access_token: 'G_ACCESS_2', expires_in: 3599 } : { access_token: 'G_ACCESS', refresh_token: 'G_REFRESH', expires_in: 3599 })],
    ['GET', /^\/youtube\/v3\/channels$/, () => ({ items: [{ id: 'UC_MAYA', snippet: { title: 'Maya Creates', thumbnails: { default: { url: 'https://yt.example/a.jpg' } } }, statistics: { subscriberCount: '90500', viewCount: '5400000', videoCount: '210' } }] })],
    ['GET', /^\/youtube\/v3\/commentThreads$/, () => ({ items: [{
      id: 'yt_thread1', snippet: { videoId: 'VID1', topLevelComment: { id: 'yt_c1', snippet: { authorDisplayName: 'Leo', authorChannelId: { value: 'UC_LEO' }, textOriginal: 'Can you review the new camera? When is the next video?', publishedAt: t(50) } } },
      replies: { comments: [] },
    }] })],
    ['POST', /^\/youtube\/v3\/comments$/, () => ({ id: 'yt_reply1', snippet: { publishedAt: new Date().toISOString() } })],
    ['GET', /^\/gmail\/v1\/users\/me\/profile$/, () => ({ emailAddress: 'maya@gmail.com' })],
    ['GET', /^\/gmail\/v1\/users\/me\/messages$/, () => ({ messages: [{ id: 'gm1', threadId: 'gth1' }] })],
    ['GET', /^\/gmail\/v1\/users\/me\/messages\/gm1$/, () => ({
      id: 'gm1', threadId: 'gth1', internalDate: String(Date.now() - 3600e3), snippet: 'Collab proposal',
      payload: { mimeType: 'multipart/alternative', headers: [
        { name: 'From', value: 'Northwind Athletics <partners@northwind.example>' }, { name: 'Subject', value: 'Paid campaign – Spring launch' }, { name: 'Message-ID', value: '<abc123@northwind.example>' },
      ], parts: [{ mimeType: 'text/plain', body: { data: Buffer.from('Hi Maya,\nWe would like to offer a sponsorship for our spring campaign. Deadline to confirm is tomorrow.\n\nOn Mon, someone wrote:\n> old stuff').toString('base64url') } }] },
    })],
    ['POST', /^\/gmail\/v1\/users\/me\/messages\/send$/, () => ({ id: 'gm_sent1', threadId: 'gth1' })],

    // ---------- Push services (Apple / Google push servers) ----------
    ['POST', /^\/push\/gone$/, () => ({ __status: 410 })],
    ['POST', /^\/push\/ok\d*$/, () => ({ __status: 201 })],

    // ---------- Telegram ----------
    ['POST', /^\/botTGTOKEN\/(sendMessage|sendPhoto|setWebhook|deleteWebhook)$/, (q, body) => ({ ok: true, result: { message_id: 900 + calls.length, chat: { id: body.chat_id } } })],
  ];

  const server = http.createServer((req, res) => {
    const chunks = [];
    req.on('data', (d) => chunks.push(d));
    req.on('end', () => {
      const rawBuf = Buffer.concat(chunks);
      const raw = rawBuf.toString('utf8');
      const u = new URL(req.url, 'http://x');
      const q = Object.fromEntries(u.searchParams);
      let body = {};
      let form = {};
      if ((req.headers['content-type'] || '').includes('json') && raw) body = JSON.parse(raw);
      if ((req.headers['content-type'] || '').includes('urlencoded')) form = Object.fromEntries(new URLSearchParams(raw));
      calls.push({ method: req.method, path: u.pathname, query: q, body, form, auth: req.headers.authorization || '', headers: req.headers, rawBuf });
      const route = routes.find(([m, rx]) => m === req.method && rx.test(u.pathname));
      let out = route ? route[2](q, body, form) : { __status: 404, error: { message: 'mock: no route ' + req.method + ' ' + u.pathname } };
      const status = out.__status || 200;
      delete out.__status;
      res.writeHead(status, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(out));
    });
  });
  return new Promise((resolve) => server.listen(port, () => resolve({ calls, close: () => server.close(), now })));
}

module.exports = startMock;
