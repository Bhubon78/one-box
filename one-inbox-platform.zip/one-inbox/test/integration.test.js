// End-to-end test: real Postgres + the real server + a fake platform API.
// Run with: npm test
const test = require('node:test');
const assert = require('node:assert');
const startPg = require('./pg');
const startMock = require('./mock-platforms');

// A fake Apple/Google push server. Real ones are HTTPS-only, so this one is too (self-signed, tests only).
function startPushService(port, calls) {
  const https = require('https');
  const { execSync } = require('child_process');
  const dir = require('fs').mkdtempSync('/tmp/push-cert-');
  execSync(`openssl req -x509 -newkey ec -pkeyopt ec_paramgen_curve:prime256v1 -nodes -keyout ${dir}/k.pem -out ${dir}/c.pem -days 1 -subj /CN=localhost 2>/dev/null`);
  process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
  const fs = require('fs');
  const server = https.createServer({ key: fs.readFileSync(`${dir}/k.pem`), cert: fs.readFileSync(`${dir}/c.pem`) }, (req, res) => {
    const chunks = [];
    req.on('data', (d) => chunks.push(d));
    req.on('end', () => {
      const path = new URL(req.url, 'https://x').pathname;
      calls.push({ method: req.method, path, headers: req.headers, rawBuf: Buffer.concat(chunks) });
      res.writeHead(path === '/push/gone' ? 410 : 201);
      res.end();
    });
  });
  return new Promise((resolve) => server.listen(port, () => resolve(server)));
}

const PORT = 3911, MOCK = 3912, PUSH = 3913;
let pg, mock, srv, db, cookie, cookie2, pushSrv;
const B = `http://localhost:${PORT}/api`;
const H = () => ({ 'Content-Type': 'application/json', 'X-Requested-With': 'onebox', Cookie: cookie });
const get = (p, c = cookie) => fetch(B + p, { headers: { Cookie: c }, redirect: 'manual' });
const post = (p, body, c = cookie) => fetch(B + p, { method: 'POST', headers: { ...H(), Cookie: c }, body: JSON.stringify(body || {}) });

// A fake phone: real P-256 keys, so the server's encrypted notifications can be decrypted here.
const crypto = require('crypto');
function fakePhone(path) {
  const ecdh = crypto.createECDH('prime256v1');
  ecdh.generateKeys();
  const auth = crypto.randomBytes(16);
  return {
    ecdh, auth,
    subscription: { endpoint: `https://localhost:${PUSH}/push/${path}`, keys: { p256dh: ecdh.getPublicKey().toString('base64url'), auth: auth.toString('base64url') } },
    read(call) {
      const ece = require('http_ece');
      return JSON.parse(ece.decrypt(call.rawBuf, { version: 'aes128gcm', privateKey: this.ecdh, authSecret: this.auth }).toString('utf8'));
    },
  };
}
let phone;

async function connect(platform) {
  const start = await get(`/connect/${platform}`);
  assert.strictEqual(start.status, 302);
  const state = new URL(start.headers.get('location')).searchParams.get('state');
  assert.ok(state, 'redirect carries a state value');
  const cb = await get(`/connect/${platform}/callback?code=CODE123&state=${state}`);
  assert.strictEqual(cb.status, 302);
  const loc = cb.headers.get('location');
  assert.match(loc, new RegExp(`connected=${platform}`), 'callback succeeded: ' + decodeURIComponent(loc));
  // The first sync runs in the background right after connecting: wait for it.
  for (let i = 0; i < 50; i++) {
    const row = await db.one(`select last_sync_at from connections where platform = $1`, [platform]);
    if (row && row.last_sync_at) break;
    await new Promise((r) => setTimeout(r, 100));
  }
  return start.headers.get('location');
}

test.before(async () => {
  pg = await startPg(54340);
  mock = await startMock(MOCK);
  pushSrv = await startPushService(PUSH, mock.calls);
  const m = `http://localhost:${MOCK}`;
  Object.assign(process.env, {
    DATABASE_URL: pg.url, ENCRYPTION_KEY: 'k'.repeat(48), PUBLIC_URL: `http://localhost:${PORT}`, CRON_SECRET: 'cronsecret',
    META_APP_ID: 'FBAPP', META_APP_SECRET: 'FBSECRET', INSTAGRAM_APP_ID: 'IGAPP', INSTAGRAM_APP_SECRET: 'IGSECRET',
    GOOGLE_CLIENT_ID: 'GID', GOOGLE_CLIENT_SECRET: 'GSECRET', TELEGRAM_BOT_TOKEN: 'TGTOKEN', TELEGRAM_BOT_USERNAME: 'OneInboxBot', TELEGRAM_WEBHOOK_SECRET: 'tgsecret',
    ANTHROPIC_API_KEY: '',
    HOST_GRAPH_FACEBOOK: m, HOST_GRAPH_INSTAGRAM: m, HOST_API_INSTAGRAM: m, HOST_WWW_INSTAGRAM: m, HOST_WWW_FACEBOOK: m,
    HOST_GOOGLE_ACCOUNTS: m, HOST_GOOGLE_OAUTH: m, HOST_GOOGLE_APIS: m, HOST_GMAIL: m, HOST_TELEGRAM: m,
  });
  db = require('../server/db');
  await db.migrate();
  srv = require('../server/index').createApp().listen(PORT);
  let r = await post('/auth/signup', { email: 'maya@example.com', password: 'creator-pass-123', name: 'Maya' }, '');
  cookie = r.headers.get('set-cookie').split(';')[0];
  r = await post('/auth/signup', { email: 'other@example.com', password: 'other-pass-1234' }, '');
  cookie2 = r.headers.get('set-cookie').split(';')[0];
});

test.after(async () => {
  srv.close();
  mock.close();
  pushSrv.close();
  await db.close();
  await pg.stop();
});

test('Notifications: subscribe a phone, bad subscriptions refused', async () => {
  const key = await (await get('/push/key')).json();
  assert.ok(key.key && key.key.length > 80, 'public key created automatically');
  const again = await (await get('/push/key')).json();
  assert.strictEqual(again.key, key.key, 'same key every time');
  phone = fakePhone('ok1');
  let r = await post('/push/subscribe', { subscription: phone.subscription });
  assert.strictEqual(r.status, 200, await r.clone().text());
  r = await post('/push/subscribe', { subscription: { endpoint: 'javascript:alert(1)', keys: { p256dh: 'x', auth: 'y' } } });
  assert.strictEqual(r.status, 400);
  r = await post('/push/subscribe', { subscription: { endpoint: 'http://evil.example/x', keys: { p256dh: 'x', auth: 'y' } } });
  assert.strictEqual(r.status, 400, 'non-https endpoints refused');
  r = await post('/push/subscribe', { subscription: { endpoint: `http://localhost:${MOCK}/push/ok1`, keys: phone.subscription.keys } });
  assert.strictEqual(r.status, 400, 'plain http refused even on localhost');
  r = await post('/push/test');
  assert.strictEqual(r.status, 200);
  const call = mock.calls.filter((c) => c.path === '/push/ok1').pop();
  assert.strictEqual(call.headers['content-encoding'], 'aes128gcm');
  assert.match(call.headers.authorization, /^vapid t=/);
  assert.deepStrictEqual(phone.read(call), { title: 'Notifications are on', body: "You'll hear about brand deals and urgent messages here.", url: '/overview', tag: 'test' });
});

test('Instagram: connect, sync DMs + comments, triage, reply, react, private reply', async () => {
  const authUrl = await connect('instagram');
  assert.match(authUrl, /\/oauth\/authorize\?client_id=IGAPP/);
  assert.match(decodeURIComponent(authUrl), /instagram_business_basic,instagram_business_manage_messages,instagram_business_manage_comments/);
  const tokenCall = mock.calls.find((c) => c.path === '/oauth/access_token');
  assert.strictEqual(tokenCall.form.grant_type, 'authorization_code');
  assert.strictEqual(tokenCall.form.redirect_uri, `http://localhost:${PORT}/api/connect/instagram/callback`);

  const conn = await db.one(`select * from connections where platform = 'instagram'`);
  assert.strictEqual(conn.account_name, '@maya.creates');
  assert.ok(conn.token_enc && !conn.token_enc.includes('IG_LONG'), 'token is stored encrypted');
  assert.ok(new Date(conn.token_expires_at) > new Date(Date.now() + 50 * 864e5));

  const s = await post(`/connections/${conn.id}/sync`);
  assert.strictEqual(s.status, 200, await s.clone().text());

  const list = await (await get('/conversations?platform=instagram')).json();
  assert.strictEqual(list.length, 3, 'one DM + two comments');
  const dm = list.find((c) => c.title === '@glowskin.co');
  assert.ok(dm, 'DM thread named after the other person');
  assert.strictEqual(dm.category, 'brand_deal');
  assert.strictEqual(dm.urgent, true);
  assert.strictEqual(dm.needs_reply, true);
  const spam = list.find((c) => c.participant_name === '@crypto_bot77');
  assert.strictEqual(spam.category, 'spam');
  assert.strictEqual(spam.needs_reply, false);

  const pushes = mock.calls.filter((c) => c.path === '/push/ok1').slice(1).map((c) => phone.read(c));
  const deal = pushes.find((p) => p.title === 'Brand deal from @glowskin.co');
  assert.ok(deal, 'brand deal notification sent: ' + JSON.stringify(pushes.map((p) => p.title)));
  assert.strictEqual(deal.url, `/inbox/${dm.id}`);
  assert.match(deal.body, /paid partnership/);
  assert.ok(!pushes.some((p) => /crypto_bot77/.test(p.title)), 'no notification for spam');
  assert.ok(!pushes.some((p) => /fan_amy/.test(p.title)), 'fan comment is not "important"');

  const thread = await (await get(`/conversations/${dm.id}`)).json();
  assert.deepStrictEqual(thread.messages.map((m) => m.direction), ['out', 'in'], 'messages oldest first, own message marked out');
  assert.ok(thread.windowOpen);
  assert.ok(thread.conversation.ai_reply.length > 10, 'has a suggested reply');

  let r = await post(`/conversations/${dm.id}/reply`, { text: 'Hi! Sounds great, sending my media kit now.' });
  assert.strictEqual(r.status, 200, await r.clone().text());
  const sent = mock.calls.filter((c) => c.path === '/v25.0/17841400000000001/messages').pop();
  assert.deepStrictEqual(sent.body, { recipient: { id: 'IGSID_BRAND' }, message: { text: 'Hi! Sounds great, sending my media kit now.' } });
  assert.strictEqual(sent.auth, 'Bearer IG_LONG');
  const after = await (await get(`/conversations/${dm.id}`)).json();
  assert.strictEqual(after.messages.at(-1).direction, 'out');
  assert.strictEqual(after.conversation.needs_reply, false);

  r = await post(`/conversations/${dm.id}/reply`, { imageUrl: 'https://cdn.example/kit.png' });
  assert.strictEqual(r.status, 200);
  const img = mock.calls.filter((c) => c.path === '/v25.0/17841400000000001/messages').pop();
  assert.deepStrictEqual(img.body.message, { attachments: { type: 'image', payload: { url: 'https://cdn.example/kit.png' } } });

  const inMsg = after.messages.find((m) => m.direction === 'in');
  r = await post(`/conversations/${dm.id}/react`, { messageId: inMsg.id, emoji: '❤️' });
  assert.strictEqual(r.status, 200, await r.clone().text());
  const react = mock.calls.filter((c) => c.path === '/v25.0/17841400000000001/messages').pop();
  assert.deepStrictEqual(react.body, { recipient: { id: 'IGSID_BRAND' }, sender_action: 'react', payload: { message_id: 'm_ig_2', reaction: '❤️' } });

  const comment = list.find((c) => c.participant_name === '@fan_amy');
  r = await post(`/conversations/${comment.id}/reply`, { text: 'It is from Zara! 💛' });
  assert.strictEqual(r.status, 200);
  const pub = mock.calls.filter((c) => c.path === '/v25.0/c_ig_1/replies').pop();
  assert.strictEqual(pub.form.message, 'It is from Zara! 💛');
  r = await post(`/conversations/${comment.id}/reply`, { text: 'Sent you the link!', mode: 'private' });
  assert.strictEqual(r.status, 200);
  const priv = mock.calls.filter((c) => c.path === '/v25.0/17841400000000001/messages').pop();
  assert.deepStrictEqual(priv.body.recipient, { comment_id: 'c_ig_1' });

  // Syncing again must not duplicate anything
  await db.q(`update connections set last_sync_at = null where id = $1`, [conn.id]);
  await post(`/connections/${conn.id}/sync`);
  const again = await (await get('/conversations?platform=instagram')).json();
  assert.strictEqual(again.length, 3);
  const count = await db.one(`select count(*)::int n from messages m join conversations c on c.id = m.conversation_id where c.id = $1`, [dm.id]);
  assert.strictEqual(count.n, 4, '2 synced + 2 sent, no duplicates');
});

test('Facebook Page: Messenger + comments, reply with RESPONSE tag', async () => {
  await connect('facebook');
  const conn = await db.one(`select * from connections where platform = 'facebook'`);
  assert.strictEqual(conn.account_name, 'Maya Creates');
  await post(`/connections/${conn.id}/sync`);
  const list = await (await get('/conversations?platform=facebook')).json();
  assert.strictEqual(list.length, 2);
  const dm = list.find((c) => c.kind === 'dm');
  assert.strictEqual(dm.participant_name, 'Jo Patel');
  assert.strictEqual(dm.category, 'question');
  const r = await post(`/conversations/${dm.id}/reply`, { text: 'Yes! Booking link coming up.' });
  assert.strictEqual(r.status, 200, await r.clone().text());
  const sent = mock.calls.filter((c) => c.path === '/v25.0/PAGE1/messages').pop();
  assert.deepStrictEqual(sent.body, { recipient: { id: 'PSID_JO' }, messaging_type: 'RESPONSE', message: { text: 'Yes! Booking link coming up.' } });
  assert.strictEqual(sent.query.access_token, 'PAGE_TOKEN');
  const cm = list.find((c) => c.kind === 'comment');
  await post(`/conversations/${cm.id}/reply`, { text: 'Thank you Sam!' });
  assert.strictEqual(mock.calls.filter((c) => c.path === '/v25.0/c_fb_1/comments').pop().form.message, 'Thank you Sam!');
});

test('YouTube: comments, stats, reply to thread', async () => {
  const url = await connect('youtube');
  assert.match(decodeURIComponent(url), /youtube\.force-ssl/);
  assert.match(url, /access_type=offline/);
  const conn = await db.one(`select * from connections where platform = 'youtube'`);
  assert.ok(conn.refresh_enc, 'refresh token kept (encrypted)');
  await post(`/connections/${conn.id}/sync`);
  const list = await (await get('/conversations?platform=youtube')).json();
  assert.strictEqual(list.length, 1);
  const r = await post(`/conversations/${list[0].id}/reply`, { text: 'Yes, video on Friday!' });
  assert.strictEqual(r.status, 200);
  const sent = mock.calls.filter((c) => c.path === '/youtube/v3/comments').pop();
  assert.deepStrictEqual(sent.body, { snippet: { parentId: 'yt_c1', textOriginal: 'Yes, video on Friday!' } });
  assert.strictEqual(sent.auth, 'Bearer G_ACCESS');
  const ov = await (await get('/overview')).json();
  const yt = ov.accounts.find((a) => a.platform === 'youtube');
  assert.strictEqual(Number(yt.trend.at(-1).followers), 90500);
});

test('Gmail: brand email thread, quoted text removed, threaded reply', async () => {
  await connect('gmail');
  const conn = await db.one(`select * from connections where platform = 'gmail'`);
  assert.strictEqual(conn.account_id, 'maya@gmail.com');
  await post(`/connections/${conn.id}/sync`);
  const list = await (await get('/conversations?platform=gmail')).json();
  assert.strictEqual(list.length, 1);
  assert.strictEqual(list[0].category, 'brand_deal');
  const th = await (await get(`/conversations/${list[0].id}`)).json();
  assert.ok(!th.messages[0].text.includes('old stuff'), 'quoted reply text stripped');
  await post(`/conversations/${list[0].id}/reply`, { text: 'Hi! Happy to discuss — rates attached.' });
  const sent = mock.calls.filter((c) => c.path === '/gmail/v1/users/me/messages/send').pop();
  assert.strictEqual(sent.body.threadId, 'gth1');
  const mime = Buffer.from(sent.body.raw, 'base64url').toString('utf8');
  assert.match(mime, /^To: partners@northwind\.example\r\n/);
  assert.match(mime, /Subject: =\?UTF-8\?B\?/); // en dash in subject gets encoded
  assert.match(mime, /In-Reply-To: <abc123@northwind\.example>/);
  const body = Buffer.from(mime.split('\r\n\r\n')[1].replace(/\r\n/g, ''), 'base64').toString('utf8');
  assert.strictEqual(body, 'Hi! Happy to discuss — rates attached.');
});

test('Telegram: link code, business messages, reply as the user, forwards', async () => {
  const tgPost = (update, secret = 'tgsecret') => fetch(B + '/webhooks/telegram', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Telegram-Bot-Api-Secret-Token': secret }, body: JSON.stringify(update) });
  const wait = () => new Promise((r) => setTimeout(r, 300));
  assert.strictEqual((await tgPost({}, 'wrong')).status, 401);

  const { link } = await (await post('/connect/telegram')).json();
  assert.match(link, /^https:\/\/t\.me\/OneInboxBot\?start=/);
  const code = link.split('start=')[1];
  await tgPost({ update_id: 1, message: { message_id: 1, from: { id: 555, first_name: 'Maya', username: 'mayac' }, chat: { id: 555, type: 'private' }, date: mock.now, text: '/start ' + code } });
  await wait();
  const conn = await db.one(`select * from connections where platform = 'telegram'`);
  assert.strictEqual(conn.account_name, '@mayac');
  // reusing the code must fail
  await tgPost({ update_id: 2, message: { message_id: 2, from: { id: 666, first_name: 'Eve' }, chat: { id: 666, type: 'private' }, date: mock.now, text: '/start ' + code } });
  await wait();
  assert.strictEqual((await db.one(`select count(*)::int n from connections where platform = 'telegram'`)).n, 1);

  await tgPost({ update_id: 3, business_connection: { id: 'BC1', user: { id: 555 }, user_chat_id: 555, is_enabled: true, rights: { can_reply: true }, date: mock.now } });
  await wait();
  await tgPost({ update_id: 4, business_message: { business_connection_id: 'BC1', message_id: 77, from: { id: 999, first_name: 'Priya' }, chat: { id: 999, type: 'private', first_name: 'Priya' }, date: mock.now, text: 'Are you free for a podcast interview next week?' } });
  await wait();
  const list = await (await get('/conversations?platform=telegram')).json();
  const chat = list.find((c) => c.participant_name === 'Priya');
  assert.ok(chat);
  assert.strictEqual(chat.category, 'collab');
  const r = await post(`/conversations/${chat.id}/reply`, { text: 'Yes! Tuesday works.' });
  assert.strictEqual(r.status, 200, await r.clone().text());
  const sent = mock.calls.filter((c) => c.path === '/botTGTOKEN/sendMessage').pop();
  assert.deepStrictEqual(sent.body, { business_connection_id: 'BC1', chat_id: '999', text: 'Yes! Tuesday works.' });

  await tgPost({ update_id: 5, message: { message_id: 8, from: { id: 555, first_name: 'Maya' }, chat: { id: 555, type: 'private' }, date: mock.now, text: 'Can you send the invoice today?', forward_origin: { type: 'user', date: mock.now, sender_user: { id: 1234, first_name: 'Accountant' } } } });
  await wait();
  const fwd = (await (await get('/conversations?platform=telegram')).json()).find((c) => c.participant_name === 'Accountant');
  assert.ok(fwd && fwd.urgent, 'forwarded message added and flagged urgent');
  const t = await (await get(`/conversations/${fwd.id}`)).json();
  assert.strictEqual(t.canReply, false);
});

test('Notifications: dead devices removed, "off" respected, settings kept', async () => {
  const gone = fakePhone('gone');
  await post('/push/subscribe', { subscription: gone.subscription });
  assert.strictEqual((await db.one(`select count(*)::int n from push_subscriptions`)).n, 2);
  await post('/push/test');
  assert.strictEqual((await db.one(`select count(*)::int n from push_subscriptions`)).n, 1, 'phone that uninstalled the app (410) is forgotten');
  let r = await fetch(B + '/settings', { method: 'PUT', headers: H(), body: JSON.stringify({ name: 'Maya', about: 'Skincare creator', notify: 'off' }) });
  assert.strictEqual(r.status, 200);
  const s = await (await get('/settings')).json();
  assert.strictEqual(s.notify, 'off');
  assert.strictEqual(s.about, 'Skincare creator');
  const before = mock.calls.filter((c) => c.path.startsWith('/push/')).length;
  const tgPost = (update) => fetch(B + '/webhooks/telegram', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Telegram-Bot-Api-Secret-Token': 'tgsecret' }, body: JSON.stringify(update) });
  await tgPost({ update_id: 50, business_message: { business_connection_id: 'BC1', message_id: 501, from: { id: 4242, first_name: 'Brandy' }, chat: { id: 4242, type: 'private', first_name: 'Brandy' }, date: mock.now, text: 'Paid sponsorship offer, budget £2k, need an answer today!' } });
  await new Promise((res) => setTimeout(res, 400));
  assert.strictEqual(mock.calls.filter((c) => c.path.startsWith('/push/')).length, before, 'no notification when turned off');
  r = await post('/push/unsubscribe', { endpoint: phone.subscription.endpoint });
  assert.strictEqual(r.status, 200);
  assert.strictEqual((await db.one(`select count(*)::int n from push_subscriptions`)).n, 0);
});

test('Privacy: users only ever see their own data', async () => {
  const mine = await (await get('/conversations')).json();
  assert.ok(mine.length >= 5);
  const theirs = await (await get('/conversations', cookie2)).json();
  assert.strictEqual(theirs.length, 0);
  const r = await get(`/conversations/${mine[0].id}`, cookie2);
  assert.strictEqual(r.status, 404);
  const rep = await post(`/conversations/${mine[0].id}/reply`, { text: 'hacked' }, cookie2);
  assert.strictEqual(rep.status, 404);
  const conns = await (await get('/connections', cookie2)).json();
  assert.strictEqual(conns.length, 0);
  const myConns = await (await get('/connections')).json();
  const del = await fetch(B + '/connections/' + myConns[0].id, { method: 'DELETE', headers: { ...H(), Cookie: cookie2 } });
  assert.strictEqual(del.status, 404);
  const forged = await get('/connect/instagram/callback?code=x&state=forged');
  assert.match(decodeURIComponent(forged.headers.get('location')), /expired/);
});

test('Overview, filters, search, archive, cron, expired token', async () => {
  const ov = await (await get('/overview')).json();
  assert.ok(ov.totals.brand_deals >= 2);
  assert.ok(ov.byPlatform.length === 5);
  assert.ok(ov.top.length > 0 && ov.top[0].urgent, 'urgent conversations listed first');
  const deals = await (await get('/conversations?filter=brand_deal')).json();
  assert.ok(deals.every((c) => ['brand_deal', 'collab'].includes(c.category)));
  const found = await (await get('/conversations?q=' + encodeURIComponent('serum'))).json();
  assert.strictEqual(found.length, 1);
  const weird = await get('/conversations?q=' + encodeURIComponent("%' or 1=1 --"));
  assert.strictEqual(weird.status, 200);
  assert.strictEqual((await weird.json()).length, 0);
  const r = await fetch(B + '/conversations/' + found[0].id, { method: 'PATCH', headers: H(), body: JSON.stringify({ archived: true }) });
  assert.strictEqual(r.status, 200);
  assert.strictEqual((await (await get('/conversations?q=serum')).json()).length, 0);
  assert.strictEqual((await (await get('/conversations?filter=archived&q=serum')).json()).length, 1);

  assert.strictEqual((await fetch(B + '/cron')).status, 401);
  await db.q(`update connections set last_sync_at = null where platform <> 'telegram'`);
  const cron = await (await fetch(B + '/cron?key=cronsecret')).json();
  assert.strictEqual(cron.synced, 4);

  // An expired Instagram token marks the account as "reconnect" instead of crashing
  const { encrypt } = require('../server/crypto');
  const ig = await db.one(`select id from connections where platform = 'instagram'`);
  await db.q(`update connections set token_enc = $2, last_sync_at = null where id = $1`, [ig.id, encrypt('EXPIRED')]);
  await post(`/connections/${ig.id}/sync`);
  const after = await db.one(`select status, last_error from connections where id = $1`, [ig.id]);
  assert.strictEqual(after.status, 'reconnect');
  assert.match(after.last_error, /validating access token/);
});

test('Account deletion removes everything', async () => {
  let r = await post('/auth/delete-account', { password: 'wrong' });
  assert.strictEqual(r.status, 401);
  r = await post('/auth/delete-account', { password: 'creator-pass-123' });
  assert.strictEqual(r.status, 200);
  for (const t of ['connections', 'conversations', 'messages', 'stats']) {
    const n = await db.one(`select count(*)::int n from ${t}`);
    assert.strictEqual(n.n, 0, t + ' emptied');
  }
});
