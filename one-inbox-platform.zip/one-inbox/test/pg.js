// Starts a throwaway Postgres for tests.
const EmbeddedPostgres = require('embedded-postgres').default;
module.exports = async function startPg(port = 54330) {
  const dir = `/tmp/onebox-pg-${port}-${Date.now()}`;
  const pg = new EmbeddedPostgres({ databaseDir: dir, user: 'postgres', password: 'pw', port, persistent: false, onLog: () => {}, onError: () => {} });
  await pg.initialise();
  await pg.start();
  await pg.createDatabase('onebox');
  return { url: `postgres://postgres:pw@localhost:${port}/onebox`, stop: () => pg.stop() };
};
